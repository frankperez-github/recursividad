﻿using Weboo.Examen;


public class Program
{
    public static void Main()
    {
        // Adicione aquí los tests que considere necesarios

        // Una asignatura convalida todas las demás
        Test(
            // Convalidaciones
            new[,]
            {
                { true,   true,  true,  true,  true},
                { false,  true, false, false, false},
                { false, false,  true, false, false},
                { false, false, false,  true, false},
                { false, false, false, false,  true},
            },
            // Resultado esperado
            1
        );
        Test(
            // Convalidaciones
            new[,]
            {
                { true,   true,  false,  false,  false},
                { false,  true, false, false, false},
                { false, true,  true, true, false},
                { false, false, false,  true, true},
                { false, false, false, false,  true},
            },
            // Resultado esperado
            3
        );
         Test(
            // Convalidaciones
            new[,]
            {
                { true, false, false, false, false, false, false, false},
                { false, true, false, false, false, false, false, false},
                { false, false,  true, false, false, false, false, false},
                { false, false, false,  true, false, false, false, false},
                { true, true, false, false,  true, false, false ,false},
                { false, false, false, false, true, true, true, false},
                { true, true, false, true, false, false, true, true},
                { false, false, true, true, false, false, false, true}
            },
            // Resultado esperado
            3
        );
        Test(
            // Convalidaciones
            new[,]
            {
                { true, true, true, true, true, true, true, true},
                { false, true, false, false, false, false, false, false},
                { false, false,  true, false, false, false, false, false},
                { false, false, false,  true, false, false, false, false},
                { true, true, false, false,  true, false, false ,false},
                { false, false, false, false, true, true, true, false},
                { true, true, false, true, false, false, true, true},
                { false, false, true, true, false, false, false, true}
            },
            // Resultado esperado
            1
        );
        Test(
            // Convalidaciones
            new[,]
            {
                { true, true, false, true, true, false, false, false,false},
                { false, true, true, false, true, false, false, false,false},
                { false, false,  true, false, true, true, false, false,false},
                { false, false, false,  true, true, false, false, false,false},
                { false, false, false, false,  true, true, false ,false,false},
                { false, false, false, false, true, true, false, false,false},
                { false, false, false, true, false, false, false, true,false},
                { false, false, false, false, true, false, true, true,true},
                { false, false, false, false, true, false, false, false, true},
            },
            // Resultado esperado
            3
        );
        Test(
            // Convalidaciones
            new[,]
            {
                { true, true, false, false, false, false, false, true},
                { false, true, true, false, true, false, false, false},
                { false, false,  true, false, false, false, false, false},
                { false, false, true,  true, true, false, false, false},
                { false, false, false, false,  true, false, false ,false},
                { false, false, false, false, false, true, false, false},
                { false, false, false, false, false, true, true, false},
                { false, false, false, false, false, false, false, true},
                
            },
            // Resultado esperado
            3
        );
        Test(
            // Convalidaciones
            new[,]
            {
                { true, true, false, true, true, false, false, false,false},
                { false, true, true, false, true, false, false, false,false},
                { false, false,  true, false, true, true, false, false,false},
                { false, false, false,  true, true, false, false, false,false},
                { false, false, false, false,  true, true, false ,false,false},
                { false, false, false, false, true, true, false, false,false},
                { false, false, false, true, false, false, false, true,false},
                { false, false, false, false, true, false, true, true,true},
                { false, false, false, false, true, false, false, false, true},
            },
            // Resultado esperado
            3
        );
        Test(
           new[,] {
               {true,true,false,true},
               {false,true,true,false},
               {false,false,true,false},
               {false,false,true,true},
               
            }
        ,2);

        // Ninguna asignatura convalida a ninguna otra
        Test(
            // Convalidaciones
            new[,]
            {
                { true,  false, false, false, false},
                { false,  true, false, false, false},
                { false, false,  true, false, false},
                { false, false, false,  true, false},
                { false, false, false, false,  true},
            },
            // Resultado esperado
            5
        );
    }

    public static void Test(bool[,] convalidaciones, int esperado)
    {
        try
        {
            bool[] solucion = Examenes.MinimoEstudio(convalidaciones);

            // Contamos la cantidad de asignaturas aprobadas
            int resultado = solucion.Count(x => x);

            if (resultado != esperado)
            {
                throw new Exception(string.Format("Se esperaba {0} pero se obtuvo {1}", esperado, resultado));
            }

            // Validamos la solución
            for (int i = 0; i < convalidaciones.GetLength(1); i++)
            {
                // Si no se aprobó la asignatura
                if (!solucion[i])
                {
                    bool convalidada = false;
                    for (int j = 0; j < convalidaciones.GetLength(0); j++)
                    {
                        if (convalidaciones[j, i] && solucion[j])
                        {
                            convalidada = true;
                            break;
                        }
                    }
                    // Si tampoco está convalidada entonces es inválida la solución
                    if (!convalidada)
                    {
                        throw new Exception("La solución retornada no es válida");
                    }
                }
            }

            Console.WriteLine("🟢 Resultado correcto: {0}", resultado);
        }
        catch (Exception e)
        {
            Console.WriteLine("🔴 {0}", e);
        }
    }
}
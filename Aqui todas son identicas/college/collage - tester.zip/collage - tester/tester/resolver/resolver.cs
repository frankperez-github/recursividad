﻿namespace Weboo.Examen
{

    public class TestResolverEficiente
    {

    }

    public class TestResolver
    {
       static bool[] best_sol = new bool[1];
        static int best = int.MaxValue; 
        public static bool[] MinimoEstudio(bool[,] convalidaciones)
        {
            best = int.MaxValue;
            best_sol = new bool[1];
            MinimoEstudio(convalidaciones, 0, 0, new bool[convalidaciones.GetLength(0)], new int[convalidaciones.GetLength(0)], 0);
            return best_sol;
        }
        public static void MinimoEstudio(bool[,] convalidaciones, int index, int sol, bool[] pruebas_hechas, int[] pruebas_aprobadas, int cant_aprobadas)
        {
            if(sol >= best)
                return;
            if(cant_aprobadas == pruebas_hechas.Length)
            {   
                best_sol = (bool[])pruebas_hechas.Clone();
                best = sol;
                return;
            }
            if(index == pruebas_hechas.Length)
                return;

            
            int nuevas_aprobadas = Hacer_prueba(index, convalidaciones, pruebas_aprobadas,1);

            if(nuevas_aprobadas > 0)
            {
                pruebas_hechas[index] = true;
                MinimoEstudio(convalidaciones, index + 1, sol + 1, pruebas_hechas, pruebas_aprobadas, cant_aprobadas + nuevas_aprobadas);
                pruebas_hechas[index] = false;
            }
            nuevas_aprobadas = Hacer_prueba(index, convalidaciones, pruebas_aprobadas, -1);
            MinimoEstudio(convalidaciones, index + 1, sol, pruebas_hechas, pruebas_aprobadas, cant_aprobadas);
        }

        public static int  Hacer_prueba(int index, bool[,] convalidaciones, int[] pruebas_aprobadas, int value)
        {
            int aux = 0;
            for (int i = 0; i < pruebas_aprobadas.Length; i++)
            {
                if(convalidaciones[index,i]){
                    if(pruebas_aprobadas[i] == 0)
                        aux++;
                    pruebas_aprobadas[i] += value;
                }
            }
            return aux;
        }

    }
}

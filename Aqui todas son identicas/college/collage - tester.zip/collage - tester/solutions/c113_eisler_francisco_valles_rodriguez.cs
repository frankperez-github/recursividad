﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weboo.Examen
{
    public class Examenes
    {
        public static int remover;
        public static int columFin;
        public static bool[] MinimoEstudio(bool[,] convalidaciones)
        {
            minmin = int.MaxValue;
            shortcamino = new List<int>();
            remover = 0;
            columFin = convalidaciones.GetLength(1) - 1;
            bool[] respuesta = new bool[convalidaciones.GetLength(1)];
            for (int i = 0; i < respuesta.Length; i++)
            {
                respuesta[i] = true;
            }
            convalidaciones2(convalidaciones, 0, 0, new List<int>(), 0);
            while (shortcamino.Count == 0 && columFin > 0)
            {
                columFin--;
                convalidaciones2(convalidaciones, 0, 0, new List<int>(), 0);
            }

            if (shortcamino.Count != 0)
            {

                foreach (var item in shortcamino)
                {
                    respuesta[item] = false;
                }
            }
            
           
            return respuesta;
     
        }
        public static int minmin;
        public static List<int> shortcamino;

        private static void convalidaciones2(bool[,] convalidaciones, int filaIni, int columIni, List<int> camino, int min)
        {
            if (columIni == columFin)
            {

                if (min < minmin)
                {
                    minmin = min;
                    for (int i = 0; i < camino.Count; i++)
                    {
                        shortcamino.Add(camino[i]);
                    }
                }
                if (camino.Count == 0)
                {
                    return;
                }
            }
            else
            {
                int[] df = { 1, -1, 0, 0 };
                int[] dc = { 0, 0, 1, -1 };
                for (int i = 0; i < df.Length; i++)
                {
                    int fila = filaIni + df[i];
                    int columna = columIni + dc[i];
                    if (fila < 0 || fila >= convalidaciones.GetLength(0) || columna < 0 || columna >= convalidaciones.GetLength(1))
                    {
                        continue;
                    }
                    if (convalidaciones[fila, columna])
                    {
                        convalidaciones[fila, columna] = false;
                        remover = columna;
                        camino.Add(remover);
                        convalidaciones2(convalidaciones, fila, columna, camino, min + 1);
                        camino.RemoveAt(camino.Count - 1);
                        convalidaciones[fila, columna] = true;
                        remover = 0;
                    }

                }
            }

        }
    }

}

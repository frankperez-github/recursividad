﻿namespace Weboo.Examen
{
    public class Examenes
    {
        public static bool[] MinimoEstudio(bool[,] convalidaciones)
        {
            int min = int.MaxValue;
            bool[] pfff = { true, true, true, true, true };
            Dictionary<int, List<int>> Orden = LlenarDicc(convalidaciones);
            ProbandoCursos(new bool[convalidaciones.GetLength(0)], 0, convalidaciones, ref min, Orden);
            return pfff;
        }
        static void ProbandoCursos(bool[] asignaturas, int indice, bool[,] convalidaciones, ref int min, Dictionary<int, List<int>> Coord)
        {
            if (indice == asignaturas.Length)
            {
                min = Math.Min(ConvalidarAsig(asignaturas, Coord), min);
                return;
            }

            ProbandoCursos(asignaturas, indice + 1, convalidaciones, ref min, Coord);
            asignaturas[indice] = true;
            ProbandoCursos(asignaturas, indice + 1, convalidaciones, ref min, Coord);
            asignaturas[indice] = false;
        }
        static Dictionary<int, List<int>> LlenarDicc(bool[,] convalidaciones)
        {


            Dictionary<int, List<int>> Coord = new();
            List<int> valores = new();
            for (int i = 0; i < convalidaciones.GetLength(0); i++)
            {
                for (int j = 0; j < convalidaciones.GetLength(1); j++)
                {
                    if (convalidaciones[i, j])
                    {

                        for (int k = j; k < convalidaciones.GetLength(1); k++)
                        {
                            if (convalidaciones[i, k])
                            {

                                // Coord.Add(i, valores);
                                // valores.Add(k);
                            }

                        }

                    }
                }
            }
            return Coord;
        }
        static int ConvalidarAsig(bool[] asignaturas, Dictionary<int, List<int>> Coord)
        {
            int Count = 0;
            for (int i = 0; i < asignaturas.Length; i++)
            {
                if (asignaturas[i])
                {
                    Count++;
                    if (Coord.ContainsKey(i))
                    {
                        if (Coord.Values.Count == asignaturas.Length)
                        {
                            return Count;
                        }
                    }
                }
            }
            return int.MaxValue;
        }


    }

}


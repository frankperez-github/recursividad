﻿namespace Weboo.Examen
{
    public class Examenes
    {
        public static bool[] MinimoEstudio(bool[,] convalidaciones)
        {
            bool[] asignaturas = new bool[convalidaciones.GetLength(0)];

            return MinimoEstudio(convalidaciones, convalidaciones.GetLength(0), asignaturas);
        }

        public static bool[] MinimoEstudio(bool[,] convalidaciones, int descuento, bool[] cantidad_convalidaciones)
        {
            if (descuento == 0)
                return cantidad_convalidaciones;

            List<int> lista = CantidaDeConvalidaciones(convalidaciones).ToList();

            for (int i = 0; i < lista.Count(); i++)
            {
                if (convalidaciones[lista.IndexOf(Mayor(lista)), i] == true)
                {
                    cantidad_convalidaciones[lista.IndexOf(Mayor(lista))] = true;
                }
            }

            int reserva = lista.IndexOf(Mayor(lista));

            lista.RemoveAt(lista.IndexOf(Mayor(lista)));

            return MinimoEstudio(convalidaciones, lista.Count() - reserva , cantidad_convalidaciones);
        }

        private static int[] CantidaDeConvalidaciones(bool[,] convalidaciones)
        {
            List<int[]> lista = new List<int[]>();

            for (int i = 0; i < convalidaciones.GetLength(0); i++)
            {
                int[] cantidad_convalidaciones = new int[convalidaciones.GetLength(0)];

                for (int j = 0; j < cantidad_convalidaciones.Length; j++)
                {
                    if (convalidaciones[i, j] == true)
                    {
                        cantidad_convalidaciones[i] = 1;
                        cantidad_convalidaciones[j] = 2;
                    }
                }

                lista.Add(cantidad_convalidaciones);
            }

            int[] respuesta = new int[convalidaciones.GetLength(1)];

            for (int i = 0; i < lista.Count(); i++)
            {
                int contador = 0;

                for (int j = 0; j < respuesta.Length; j++)
                {
                    if (lista[i][j] == 2)
                        contador++;
                }

                respuesta[i] = contador;
            }

            return respuesta;
        }

        private static int Mayor(List<int> lista)
        {
            int contador = int.MinValue;

            for (int i = 0; i < lista.Count(); i++)
            {
                if (lista[i] > contador)
                    contador = lista[i];
            }

            return contador;
        }
    }
}

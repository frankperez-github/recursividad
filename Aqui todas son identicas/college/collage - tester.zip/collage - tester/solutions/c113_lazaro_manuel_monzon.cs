﻿namespace Weboo.Examen
{
    public class Examenes
    {
        public static bool[] boleanos = new bool[] { true, false };
        public static List<bool[]> ListaFinal = new List<bool[]>();
        public static int[] CantidadDeTrues;


        public static bool[] MinimoEstudio(bool[,] convalidaciones)
        {
            ListaFinal.Clear();
            AlgoRaro(ListaFinal, convalidaciones, 0, new bool[convalidaciones.GetLength(0)], boleanos, new bool[boleanos.Length]);
            CantidadDeTrues = new int[ListaFinal.Count];
            UbicarCantidadDeVerdaderos(ListaFinal);
            return ListaFinal[ExtraccionDeIndice(CantidadDeTrues)];
        }

        public static void AlgoRaro(List<bool[]> ListaFinal, bool[,] Convalidaciones, int cuantas, bool[] ConvalidacionesComb, bool[] bolenaos, bool[] marks)
        {
            bool[] prueba = new bool[ConvalidacionesComb.Length];
            if (cuantas == ConvalidacionesComb.Length)
            {
                if (Valida(Convalidaciones, ConvalidacionesComb))
                {
                    System.Array.Copy(ConvalidacionesComb, prueba, ConvalidacionesComb.Length);
                    ListaFinal.Add(prueba);
                }
            }
            else
            {
                for (int i = 0; i < bolenaos.Length; i++)
                {
                    {
                        ConvalidacionesComb[cuantas] = bolenaos[i];
                        AlgoRaro(ListaFinal, Convalidaciones, cuantas + 1, ConvalidacionesComb, bolenaos, marks);
                    }

                }
            }

        }

        static bool IsValid(bool[,] convalidaciones, bool[] algoRaro)
        {
            int suma = 0;
            for (int i = 0; i < algoRaro.Length; i++)
            {
                if (algoRaro[i])
                    suma += RevisarConvalidacion(convalidaciones, i);
            }

            if (suma >= convalidaciones.GetLength(0))
            {

                return true;
            }

            return false;
        }

        static int RevisarConvalidacion(bool[,] convalidaciones, int Fila)
        {
            int suma = 0;
            for (int j = 0; j < convalidaciones.GetLength(1); j++)
            {
                if (convalidaciones[Fila, j])
                {
                    suma++;
                }
            }
            return suma;
        }

        static int TrueCount(bool[] combinacionesFInales)
        {
            int suma = 0;
            for (int i = 0; i < combinacionesFInales.Length; i++)
            {
                if (combinacionesFInales[i])
                    suma++;
            }
            return suma;
        }

        static void UbicarCantidadDeVerdaderos(List<bool[]> ListaFinal)
        {
            for (int i = 0; i < ListaFinal.Count; i++)
            {

                CantidadDeTrues[i] = TrueCount(ListaFinal[i]);

            }
        }

        public static int ExtraccionDeIndice(int[] sumaT)
        {
            for (int i = 0; i < sumaT.Length; i++)
            {
                if (sumaT[i] == 0)
                {
                    sumaT[i] = 100;
                }
            }
            int indice = 0;
            for (int i = indice; i < sumaT.Length - 1; i++)
            {
                if (sumaT[indice] > sumaT[i + 1])
                {
                    indice = i + 1;
                }

            }

            return indice;
        }

        public static bool Valida(bool[,] convalidaciones, bool[] solucion)
        {
            for (int i = 0; i < convalidaciones.GetLength(1); i++)
            {
                // Si no se aprobó la asignatura
                if (!solucion[i])
                {
                    bool convalidada = false;
                    for (int j = 0; j < convalidaciones.GetLength(0); j++)
                    {
                        if (convalidaciones[j, i] && solucion[j])
                        {
                            convalidada = true;
                            break;
                        }
                    }
                    // Si tampoco está convalidada entonces es inválida la solución
                    if (!convalidada)
                    {
                        return false;
                    }
                }


            }
            return true;




        }

    }
}

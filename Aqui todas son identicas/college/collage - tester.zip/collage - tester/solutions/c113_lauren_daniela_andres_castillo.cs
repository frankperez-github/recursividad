﻿namespace Weboo.Examen
{
    public class Examenes
    {
        public static bool[] MinimoEstudio(bool[,] convalidaciones)
        {
            bool[] asignaturas = {true, false, true, false};
            if(EnRango(convalidaciones))
            {
                for (int i = 0; i < convalidaciones.GetLength(0); i++)
                {
                    for (int j = 0; j < convalidaciones.GetLength(1); j++)
                    {
                        if(!asignaturas[i] == asignaturas[j])
                        {
                            asignaturas[i] = false;
                            asignaturas[j] = true;
                        }
                        else
                        {
                            asignaturas[i] = true;
                            asignaturas[j] = false;   
                        }
                    }
                }
            }
            return asignaturas = MinimoEstudio1(convalidaciones, asignaturas, true);
        }

        static bool[] MinimoEstudio1(bool[,] convalidaciones, bool[] asignaturas, bool aprobada)
        {

            for (int i = 0; i < asignaturas.Length; i++)
            {
                bool aprobadas = true;
                if(!asignaturas[i])
                {
                    aprobadas = false;
                }        
            }

            if(EnRango(convalidaciones))
            {
                for (int i = 0; i < convalidaciones.GetLength(0); i++)
                {
                    for (int j = 0; j < convalidaciones.GetLength(1); j++)
                    {
                        if(asignaturas[i] == asignaturas[j])
                        {
                            asignaturas[i] = true;
                            asignaturas[j] = true;
                        }
                        else if(asignaturas[i] != asignaturas[j])
                        {
                            asignaturas[i] = true;
                            asignaturas[j] = false;
                        }
                        else
                        {
                            asignaturas[i] = false;
                            asignaturas[j] = true;
                        }   
                    }
                }
            }
            return asignaturas =  MinimoEstudio1(convalidaciones, asignaturas, false);   
        }

       static bool EnRango(bool[,] convalidacion)
        {
            for (int i = 0; i < convalidacion.GetLength(0); i++)
            {
                for (int j = 0; j < convalidacion.GetLength(1); j++)
                {
                    if(!convalidacion[i,j])
                    {
                        return false;
                    }
                }
            }
            return true;
        }

    }

}

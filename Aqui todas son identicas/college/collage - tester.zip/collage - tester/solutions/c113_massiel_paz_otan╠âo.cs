﻿namespace Weboo.Examen
{
    public class Examenes
    {
        public static bool[] MinimoEstudio(bool[,] convalidaciones)
        {
            int k = convalidaciones.GetLength(0);
            int[] materias = new int[k];
            bool[] materias_convalidadas = new bool[k];
            bool[] nodos_actuales = new bool[k];
            bool[] nodos_min = new bool[k];
            bool[] aristas = new bool[k];
            int trues_min = int.MaxValue;
            return MinimoEstudio(convalidaciones, materias, materias_convalidadas, aristas, nodos_actuales, ref nodos_min, 0, k, 0, ref trues_min);

        }
        private static ref bool[] MinimoEstudio(bool[,] convalidaciones, int[] materias, bool[] materias_convalidadas, bool[] aristas, bool[] nodos_actuales, ref bool[] nodos_min, int index_col, int k, int trues_actuals, ref int trues_min)
        {
            if (index_col == k)
            {
                if (trues_actuals < trues_min)
                {
                    for (int i = 0; i < k; i++)
                    {
                        nodos_min[i] = nodos_actuales[i];

                    }
                }
                return ref nodos_min;
            }

            for (int i = 0; i < convalidaciones.GetLength(0); i++)
            {
                aristas[i] = convalidaciones[i, index_col];
                //if (convalidaciones[i, index_col] == true) materias[i] = i;
            }
            

            for (int i = 0; i < k; i++)
            {
                if (aristas[i])
                {
                    if (materias_convalidadas[i]) continue;
                    else
                    {
                        materias_convalidadas[i] = true;
                        if (!nodos_actuales[i])
                        {
                            nodos_actuales[i] = true;
                            MinimoEstudio(convalidaciones, materias, materias_convalidadas, aristas, nodos_actuales, ref nodos_min, index_col + 1, k, trues_actuals + 1, ref trues_min);
                        }
                        MinimoEstudio(convalidaciones, materias, materias_convalidadas, aristas, nodos_actuales, ref nodos_min, index_col + 1, k, trues_actuals, ref trues_min);
                        materias_convalidadas[i] = false;
                    }
                }
                // MinimoEstudio(convalidaciones, materias, materias_convalidadas, aristas, nodos_actuales, ref nodos_min, index_col + 1, k, trues_actuals, ref trues_min);
            }
            MinimoEstudio(convalidaciones, materias, materias_convalidadas, aristas, nodos_actuales, ref nodos_min, index_col + 1, k, trues_actuals, ref trues_min);

            return ref nodos_min;
        }

        public static bool[] Convalidadas(bool[,] convalidaciones, int index_col)
        {
            bool[] aristas = new bool[convalidaciones.GetLength(0)];
            for (int i = 0; i < convalidaciones.GetLength(0); i++)
            {
                if (convalidaciones[index_col, i] == true) aristas[i] = true;
            }
            return aristas;
        }
    }

}

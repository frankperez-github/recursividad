﻿namespace Weboo.Examen
{
    public class Examenes
    {
        public static bool[] MinimoEstudio(bool[,] convalidaciones)
        {
            int limite = convalidaciones.GetLength(0);
            //convirtiendo a jagged array para una mayor comodidad personal
            bool[][] convalidaziones = new bool[limite][];
            for (int i = 0; i < limite; i++)
            {
                bool[] temp = new bool[limite];
                for (int j = 0; j < limite; j++)
                {
                    temp[j] = convalidaciones[i, j];
                }
                convalidaziones[i] = temp;
            }
            //resolviendo el problema haciendo todas las combinaciones posibles entre todas las
            //convalidaciones q provoca cada asignatura
            List<int> direcciones = new List<int>();
            bool founded = false;
            int countTrues = 0;
            for (int i = 0; i < limite; i++)
            {
                if (founded)
                    break;
                for (int j = 1; j < limite; j++)
                {
                    if (founded)
                        break;
                    bool[] resultX = Comb(convalidaziones[i], convalidaziones[j]);
                    for (int h = 0; h < resultX.Length; h++)
                    {
                        if (!resultX[h])
                            break;
                        if (convalidaziones[i][h])
                        {
                            countTrues++;
                        }
                        if (h + 1 == resultX.Length)
                        {
                            if (countTrues == convalidaziones[i].Length)
                            {
                                direcciones[i] = i;
                                founded = true;
                            }
                            else
                            {
                                direcciones[i] = i;
                                direcciones[j] = j;
                                founded = true;
                            }
                        }
                    }

                }
            }
            bool[] result = new bool[limite];
            for (int i = 0; i < direcciones.Count; i++)
            {
                result[direcciones[i]] = true;
            }
            return result;
        }
        //uniendo los bool mediante el "||" mi teclado no tiene tilde xd
        //y si da true completo pues eso significa q esas dos asignaturas son suficientes para 
        //convalidarlas todas
        //se q tengo q hacer esto para n casos ,o sea no solo combinar dos y ya.
        //debo hacer combinaciones de 2 y 3 y 4 y asi.
        public static bool[] Comb(bool[] a, bool[] b)
        {
            bool[] result = new bool[a.Length];
            for (int i = 0; i < a.Length; i++)
            {
                result[i] = a[i] || b[i];
            }
            return result;
        }
    }

}

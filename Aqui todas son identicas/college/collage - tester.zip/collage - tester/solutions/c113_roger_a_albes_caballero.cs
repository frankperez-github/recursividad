﻿namespace Weboo.Examen
{
    public class Examenes
    {

        public static bool[] MinimoEstudio(bool[,] convalidaciones)
        {

            bool[,] mask = new bool[convalidaciones.GetLength(0), convalidaciones.GetLength(1)];

            return Asign_Convalida(convalidaciones, mask, 0, 0);

        }

        static bool[] Asign_Convalida(bool[,] asignatura, bool[,] mask, int i, int j)
        {
            int cont = 0;
            bool[] resultado;
            int cant_asign = asignatura.GetLength(0);

            if (asignatura[i = j, j = i])
            {
                return Materias(asignatura);
            }


            for (int k = 0; k < asignatura.GetLength(0); k++)
            {

                for (int l = 0; l < asignatura.GetLength(1); l++)
                {

                    if (asignatura[k, 0] = true)
                    {
                        cont++;

                    }

                }

            }

            resultado = new bool[cont];
            return resultado;
        }

        static bool[] Materias(bool[,] array)
        {

            int cant_asign = array.GetLength(0);
            bool[] materias = new bool[cant_asign];

            for (int k = 0; k < materias.Length; k++)
            {
                materias[k] = array[k, 0];
            }

            return materias;

        }



        //int cant_asign = asignatura.GetLength(0);
        //bool[] materias = new bool[cant_asign];
    }

}

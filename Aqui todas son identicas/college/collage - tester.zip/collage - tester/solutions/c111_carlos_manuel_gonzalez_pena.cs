﻿namespace Weboo.Examen
{
    public class Examenes
    {
        public static bool[] MinimoEstudio(bool[,] convalidaciones)
        {
            int cantAsignaturas = convalidaciones.GetLength(0);
            bool[] convalidar = new bool[ cantAsignaturas ];

            (int[] sol, _) = Solve(0,cantAsignaturas, new List<int> (), convalidaciones);

            foreach(var asign in sol) {
                convalidar[ asign ] = true;
            }

            return convalidar;
        }

        static (int[], int ) Solve(int asign, int totalAsign, List<int> asignConvalidar, bool[,] convalidaciones) {

            if( asign == totalAsign ) {
                if(SpandConvalidar(asignConvalidar.ToArray(), convalidaciones)) 
                    return (asignConvalidar.ToArray(), asignConvalidar.Count);
                return (new int[0], int.MaxValue);
            }

            asignConvalidar.Add(asign);
            (int[] x1, int x2) = Solve( asign + 1, totalAsign, asignConvalidar, convalidaciones );

            asignConvalidar.RemoveAt( asignConvalidar.Count - 1 );    
            (int[] y1, int y2) = Solve( asign + 1, totalAsign, asignConvalidar, convalidaciones );

            if( x2 <= y2 )
                return (x1, x2);
            return (y1, y2);
        }

        static bool SpandConvalidar(int[] asignConvalidadas, bool[,] convalidaciones) {

            int totalAsignaturas = convalidaciones.GetLength(0);
            bool[] marked = new bool[ totalAsignaturas ];

            foreach(var asign in asignConvalidadas) {
                marked[asign] = true;
                for(int v = 0; v < totalAsignaturas; v ++)
                    if( convalidaciones[asign, v] )
                        marked[v] = true;
            }

            return !marked.Contains(false);
        }
    }
}
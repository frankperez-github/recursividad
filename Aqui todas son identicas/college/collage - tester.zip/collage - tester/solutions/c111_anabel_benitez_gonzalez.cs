﻿namespace Weboo.Examen
{
    public class Examenes
    {
        static int min;
        static bool[] best;
        public static bool[] MinimoEstudio(bool[,] convalidaciones)
        {
            if(convalidaciones == null) throw new Exception("No hay matriz");
            min = int.MaxValue;
            best = new bool[convalidaciones.GetLength(0)];
            MinimoEstudio(convalidaciones,new bool[convalidaciones.GetLength(0)],new bool[convalidaciones.GetLength(0)],0,0,0);
            // MinimoEstudio(convalidaciones,new bool[convalidaciones.GetLength(0)],0,0);
            return best;
        }

        static int MinimoEstudio(bool[,] convalidaciones, bool[] aprobadas, bool[] pasadas, int index, int LlevoAprobadas, int LlevoPasadas)
        {
            if(index == aprobadas.Length)
            {
                if(LlevoPasadas < aprobadas.Length) return int.MaxValue;
                min = LlevoAprobadas;
                Array.Copy(aprobadas, best, aprobadas.Length);
                return LlevoAprobadas;
            }
            int res = int.MaxValue;

            //si no tengo que aprobarla obligado pruebo con no aprobar la asignatura
            if(LlevoAprobadas < min && !TengoQueAprobarla(convalidaciones, aprobadas, pasadas, index))
                res = Math.Min(res, MinimoEstudio(convalidaciones, aprobadas, pasadas, index+1, LlevoAprobadas, LlevoPasadas));
            
            //si puedo pruebo con aprobarla
            if(LlevoAprobadas + 1 < min && !NoNecesitoAprobarla(convalidaciones, aprobadas, pasadas, index))
            {
                bool[] PasadasAhora = new bool[pasadas.Length];
                Array.Copy(pasadas, PasadasAhora, pasadas.Length);
                aprobadas[index] = true;
                int cont = 0; // para ver cuantas asignaturas paso aprobando esta
                //compruebo que asignaturas convalido si paso esta
                for(int i = 0; i < PasadasAhora.Length; i++)
                {
                    if(convalidaciones[index,i] && !PasadasAhora[i]) 
                    {
                        PasadasAhora[i] = true;
                        cont++;
                    }
                }
                res = Math.Min(res, MinimoEstudio(convalidaciones, aprobadas, PasadasAhora, index+1, LlevoAprobadas + 1, LlevoPasadas + cont));
                aprobadas[index] = false;
            }

            return res;
        }

        static bool NoNecesitoAprobarla(bool[,] convalidaciones, bool[] aprobadas, bool[] pasadas, int index)
        //si esta asignatura la tengo pasada, y ademas si la apruebo no convalido nada nuevo
        //entonces no tiene sentido probar con aprobarla
        {  
            if(pasadas[index])
            {
                int cont = 0;
                for(int i = 0; i < aprobadas.Length; i++)
                {
                    if(convalidaciones[index,i] && !pasadas[i]) cont++;
                }
                if(cont == 0) return true;
            }
            return false;
        }

        static bool TengoQueAprobarla(bool[,] convalidaciones, bool[] aprobadas, bool[] pasadas, int index)
        //si esta asignatura no la tengo pasada hasta ahora, y ademas ninguna posterior me la convalida
        //entonces no tiene sentido probar con suspenderla
        { 
            if(!pasadas[index]) 
            {
                int cont = 0;
                for(int i = index + 1; i < aprobadas.Length; i++)
                {
                    if(convalidaciones[i, index]) cont++;
                }
                if(cont == 0) return true;
            }
            return false;
        }


        // static int MinimoEstudio(bool[,] convalidaciones, bool[] aprobadas, int index, int LlevoAprobadas)
        // {
        //     if(index == aprobadas.Length)
        //     { 
        //         bool[] x = new bool[aprobadas.Length];
        //         int cont = 0;
        //         for(int i = 0; i < aprobadas.Length; i++)
        //         {
        //             if(!aprobadas[i]) continue;
        //             if(!x[i])
        //             {   
        //                 x[i] = true;
        //                 cont ++;
        //             }
        //             for(int j=0;j<aprobadas.Length; j++)
        //             {
        //                 if(convalidaciones[i,j] && !x[j])
        //                 {
        //                     x[j]=true;
        //                     cont++;
        //                 }
        //             }
        //         }
        //         if(cont < aprobadas.Length) return int.MaxValue;
        //             min = LlevoAprobadas;
        //             Array.Copy(aprobadas,best,aprobadas.Length);
        //             return LlevoAprobadas;
        //     }
        //     int res = int.MaxValue;
        //     if(LlevoAprobadas < min)
        //         res = Math.Min(res, MinimoEstudio(convalidaciones, aprobadas, index+1, LlevoAprobadas));
        //     if(LlevoAprobadas + 1 < min)
        //     {
        //         aprobadas[index] = true;
        //         res = Math.Min(res, MinimoEstudio(convalidaciones, aprobadas, index+1, LlevoAprobadas + 1));
        //         aprobadas[index] = false;
        //     }
        //     return res;
        // }
    }

}

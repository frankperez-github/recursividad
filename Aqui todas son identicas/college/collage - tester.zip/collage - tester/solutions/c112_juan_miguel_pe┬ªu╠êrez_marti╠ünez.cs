﻿namespace Weboo.Examen
{
    public class Examenes
    {   
        public static bool[] MinimoEstudio(bool[,] convalidaciones)
        {   
            
            
            int [] orden=new int [convalidaciones.GetLength(0)];
            bool [] menorentrega=new bool[convalidaciones.GetLength(0)];
            for(int k=0;k<orden.Length;k++){
                orden[k]=k;
            }
            Permutaciones(orden,convalidaciones,menorentrega);
            minimo=int.MaxValue;
            
            return menorentrega;
        }
        
        public static int CantidaddeVerdaderos(bool[] arraybool){
            int contador=0;
            for(int k=0;k<arraybool.Length;k++){
                if(arraybool[k]==true)contador=contador+1;
            }
            return contador;
        }
        
        public static void Permutaciones(int [] n,bool [,] convalidaciones,bool[] menorentrega ){
            Permutaciones(n,convalidaciones,new bool[n.Length],new int [n.Length],0,menorentrega);
        }
        public static int minimo=int.MaxValue;
        public static void Permutaciones(int [] n,bool[,]convalidaciones, bool [] arraybool,int [] combinacion,int indice,bool[] menorentrega  ){
            if(indice==n.Length){
                bool[] temp=Accion(combinacion,convalidaciones);
                if(CantidaddeVerdaderos(temp)<minimo){
                    
                    minimo=CantidaddeVerdaderos(temp);
                    
                    for(int i=0;i<temp.Length;i++){
                        menorentrega[i]=temp[i];
                    }
                }
               
                
                
            }
            else{
                for(int k=0;k<n.Length;k++){
                    if(arraybool[k])continue;
                    
                    if(CantidaddeVerdaderos(Accion(combinacion,convalidaciones))<minimo)
                    arraybool[k]=true;
                    combinacion[indice]=n[k];
                    
                    Permutaciones(n,convalidaciones,arraybool,combinacion,indice+1,menorentrega);
                    arraybool[k]=false;
                    
                }
                
            }
        }
        public static bool[] Accion(int [] combinacion,bool [,] convalidaciones){
            bool [] ADevolver=new bool[combinacion.Length];
            bool [] Convalidadas=new bool[combinacion.Length];
            for(int i=0;i<combinacion.Length;i++){
                if(Convalidadas[i])continue;
                ADevolver[i]=true;
                for(int k=0;k<convalidaciones.GetLength(1);k++){
                    if(convalidaciones[i,combinacion[k]]){
                        Convalidadas[combinacion[k]]=true;
                            
                        
                    }
                    
                }
            }
            return ADevolver;
        }
    }

}

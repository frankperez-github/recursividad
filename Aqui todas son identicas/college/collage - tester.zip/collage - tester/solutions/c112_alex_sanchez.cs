﻿namespace Weboo.Examen
{
    public class Examenes
    {           
        static bool[] mejores_asignaturas;
        static int minimo;
        static LinkedList<bool[]> solutions;
        public static bool[] MinimoEstudio(bool[,] convalidaciones)
        {              
            solutions=new LinkedList<bool[]>();
            mejores_asignaturas = new bool[convalidaciones.GetLength(0)];
            minimo=int.MaxValue;
             minimoAsignaturas(convalidaciones,new bool[convalidaciones.GetLength(0)],new bool[convalidaciones.GetLength(0)],0);
          //   Imprime(mejores_asignaturas);
                return mejores_asignaturas;
        }

        static void minimoAsignaturas(bool[,] convalidaciones,bool[] tomadas,bool[] mejor,int asignatura)
        {
            //if(solutions.Contains(tomadas))return;                       
          int aux =tomadas.Where(elem => elem==true).Count();   
           if(aux> minimo)return;                       
            if(ConvalidaTodas(convalidaciones,tomadas))
            {                          
               // solutions.AddLast((bool[])tomadas.Clone());
                      if(aux<=minimo)
                      {
                      SaveSolution(tomadas,mejor);
                      minimo=aux;
                      }                 
            }

              if(asignatura >= tomadas.Length)return;
         
             minimoAsignaturas(convalidaciones,tomadas,mejor,asignatura+1);           
            tomadas[asignatura]=true;
            minimoAsignaturas(convalidaciones,tomadas,mejor,asignatura+1);
            tomadas[asignatura]=false;           
        }



        static void Imprime(bool[] sol)
        {
          for(int i=0;i<sol.Length;i++)
          {
              if(sol[i])
              {
//Console.Write((i+1)+" ");
              }
          }
//Console.WriteLine();
        }


        static void SaveSolution(bool[] tomadas,bool[] mejor)
        {
                mejores_asignaturas=(bool[])tomadas.Clone();               
        }

        static bool ConvalidaTodas(bool[,] convalidaciones,bool[] tomadas)
        {
            bool[] asignaturas_convalidadas=new bool[tomadas.Length];

            for(int i=0;i<tomadas.Length;i++)
            {
                if(!tomadas[i])continue;

                    for(int j=0;j<tomadas.Length;j++)
                    {
                        if(convalidaciones[i,j])asignaturas_convalidadas[j]=true;
                    }

            }                    
            return !asignaturas_convalidadas.Any(elem => elem==false);
        }

    }

}

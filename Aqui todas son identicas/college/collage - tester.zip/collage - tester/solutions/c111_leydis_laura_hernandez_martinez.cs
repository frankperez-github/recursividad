﻿namespace Weboo.Examen
{
    public class Examenes
    {
        public static bool[] MinimoEstudio(bool[,] convalidaciones)
        {
            if(!AsignaturasRelacionadas(convalidaciones)) 
            {
                bool[] asignaturas = new bool [convalidaciones.GetLength(0)];
                for (int i = 0; i < asignaturas.Length; i++)
                {
                    asignaturas[i] = true;
                }
                return asignaturas;                
            }
            bool[] resultado = new bool[convalidaciones.GetLength(0)];
            for (int i = 1; i < resultado.Length; i++)
            {
                MenorCombinacion(convalidaciones,new bool[resultado.Length],i,0,0,resultado);
                if(CombinacionValida(convalidaciones,resultado))
                return resultado;
            }
            return resultado;
        }

        static bool AsignaturasRelacionadas(bool[,] convalidaciones)
        {
            for (int i = 0; i < convalidaciones.GetLength(0); i++)
            {
                int relaciones = 0;
                for (int j = 0; j < convalidaciones.GetLength(1); j++)
                {
                    if(convalidaciones[i,j])
                    relaciones++;                    
                }
                if(relaciones > 1)
                return true;
            }
            return false;
        }
        static bool CombinacionValida(bool[,] convalidaciones, bool[] combinacion)
        {
            bool[] asignaturas = new bool[combinacion.Length];
            
            for (int i = 0; i < combinacion.Length; i++)
            {
                if(!combinacion[i]) continue;
                asignaturas[i] = true;
                for (int j = 0; j < convalidaciones.GetLength(1); j++)
                {
                    if(i == j) continue;
                    if(!convalidaciones[i,j]) continue;
                    if(!asignaturas[j])
                    {
                        asignaturas[j] = true;
                    }
                }
                if(TodasAprobadas(asignaturas)) return true;
            }
            return false;
        }
        static bool TodasAprobadas(bool[] asignaturas)
        {
            for (int i = 0; i < asignaturas.Length; i++)
            {
                if(!asignaturas[i])
                return false;
            }
            return true;
        }
        static void MenorCombinacion(bool[,] convalidaciones, bool[] combinacion, int M, int cuantas, int menorAPoner, bool[] mejorCombinacion)
        {
            if(cuantas == M)
            {
                if(CombinacionValida(convalidaciones,combinacion))
                {
                    Array.Copy(combinacion,mejorCombinacion,combinacion.Length);
                }                
                return;
            }
            for (int i = menorAPoner; i < combinacion.Length; i++)
            {
                combinacion[i] = true;
                MenorCombinacion(convalidaciones,combinacion,M,cuantas+1,i+1,mejorCombinacion);
                if(CombinacionValida(convalidaciones,mejorCombinacion))
                break;
                combinacion[i] = false;                
            }

        }
    }

}

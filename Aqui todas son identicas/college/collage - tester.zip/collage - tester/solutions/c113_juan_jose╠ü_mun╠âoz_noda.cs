﻿namespace Weboo.Examen
{
    public class Examenes
    {
        

        public static int ContandT(bool[] asignaturas){
            int k=0;
            for(int i=0;i<asignaturas.Length;i++){
                if(asignaturas[i])
                    k++;
            }
            return k;
        }
        
        public static bool Correcto(bool[,] convalidaciones, bool[] asignaturas){
            bool[] aprobadas=new bool[asignaturas.Length];
            for(int i=0;i<asignaturas.Length;i++){
                if(asignaturas[i]){
                    aprobadas[i]=true;
                    for(int j=0;j<asignaturas.Length;j++){
                        if(i==j) continue;
                        if(convalidaciones[i,j]){
                            aprobadas[j]=true;
                        }
                    }
                }
            }

            for(int i=0;i<asignaturas.Length;i++){
                if(!aprobadas[i])
                    return false;
            }
            return true;
        }

        public static bool[] Generate(bool[,] convalidaciones)
        {   
            int k=convalidaciones.GetLength(0);
            bool[] good = GenerateRec(new int[k] , 0, new bool[k], new bool[k], new bool[2] {false,true},convalidaciones, int.MaxValue);
            return good;
        }

        public static bool[] GenerateRec(int[] asignaturas, int cuenta, bool[] mask, bool[] permutacion, bool[] asig, bool[,] convalidaciones,int min)
        {
            if (cuenta == asignaturas.Length)
            {   if(Correcto(convalidaciones,permutacion)&&ContandT(permutacion)<min){
                    min=ContandT(permutacion);
                    return permutacion;}

            }
            else
            for(int j=0;j<2;j++)
            { 
                for (int i = 0; i < asignaturas.Length; i++){
                    if(!mask[i]){
                        mask[i]=true;
                        permutacion[i]=asig[j];
                        GenerateRec(asignaturas,cuenta+1,mask,permutacion,asig, convalidaciones, min);
                        if(Correcto(convalidaciones,permutacion)&&ContandT(permutacion)<min){
                            min=ContandT(permutacion);
                            return permutacion;
                            }
                        mask[i]=false;
                        break;
                        
                }
            }
                
            }
            return permutacion;
        }

    



    public static (bool, int) FullTrue(bool[,] convalidaciones)
    {

        for (int i = 0; i < convalidaciones.GetLength(0); i++)
        {
            bool FTrue = true;
            for (int j = 0; j < convalidaciones.GetLength(1); j++)
            {
                if (i == j) continue;
                if (!convalidaciones[i, j])
                {
                    FTrue = false;
                    break;
                }
            }
            if (FTrue)
                return (FTrue, i);
        }
        return (false, -1);
    }
    public static bool FullFalse(bool[,] convalidaciones)
    {
        for (int i = 0; i < convalidaciones.GetLength(0); i++)
        {
            for (int j = 0; j < convalidaciones.GetLength(1); j++)
            {
                if (i == j) continue;
                if (convalidaciones[i, j])
                    return false;
            }
        }
        return true;
    }
    public static bool[] MinimoEstudio(bool[,] convalidaciones)
    {
        if (FullFalse(convalidaciones))
        {
            bool[] FFalse = new bool[convalidaciones.GetLength(0)];
            for (int i = 0; i < FFalse.Length; i++)
            {
                FFalse[i] = true;
            }
            return FFalse;
        }

        if (FullTrue(convalidaciones).Item1)
        {
            bool[] Asignaturas = new bool[convalidaciones.GetLength(0)];
            for (int i = 0; i < Asignaturas.Length; i++)
            {
                if (FullTrue(convalidaciones).Item2 == i)
                    Asignaturas[i] = true;
                else
                    Asignaturas[i] = false;

            }
            return Asignaturas;

        }

       

        return  Generate(convalidaciones);
    }
}

}

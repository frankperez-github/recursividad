﻿namespace Weboo.Examen
{
    public class Examenes
    {
    
        public static bool[] MinimoEstudio(bool[,] convalidaciones)
        {
            
            if (convalidaciones==null || 
                convalidaciones.GetLength(0)==0 ||
                convalidaciones.GetLength(1)==0 ||
                convalidaciones.GetLength(1) != convalidaciones.GetLength(0) ||
                !AllFalse(convalidaciones)
                ){
                bool[] cero = new bool[0];
                return cero;
                }
            
            if(!AllTopics(convalidaciones)) return Return(convalidaciones.GetLength(0), true);

            bool[] i = new bool[convalidaciones.GetLength(1)];
            bool[] mark = new bool[convalidaciones.GetLength(1)];
            bool[] resp = new bool[convalidaciones.GetLength(1)];
            bool[] respt = Return(convalidaciones.GetLength(0), true);
            
            i.CopyTo(MinStudy(convalidaciones, resp, mark,0, respt),0);
            return i;
            
        }
        public static bool[] MinStudy(bool[,] conv, bool[] respuesta, bool[] marks, int m, bool[] respuestatemp)
        {
           
            if(m==conv.GetLength(0))
            {
                if (RespuestaValida(respuesta, conv))
                {
                    if(Min(respuesta)< Min(respuestatemp)) respuesta.CopyTo(respuestatemp, m);
                }
                return respuestatemp;
            }

            if(Min(respuestatemp)==1) return respuestatemp;
            respuesta[m] = true;
            m=m+1;
            respuesta = MinStudy(conv, respuesta, marks, m, respuestatemp);
            m=m-1;
            respuesta[m] = false;
            
            return respuestatemp;
        }
        
        
        public static bool AllFalse(bool[,] array){
            for (int i = 0; i < array.GetLength(0); i++)
            {
                for (int k = 0; k < array.GetLength(1); k++)
                {
                    if(array[i,k]==true) return true;
                }
            }
            return false;
        }
        public static bool AllTopics(bool[,] array){
            int count = 0;
            for (int i = 0; i < array.GetLength(0); i++)
            {
                for (int k = 0; k < array.GetLength(1); k++)
                {
                    if(array[i,k]==true) count = count +1;
                }
            }
            if(count == array.GetLength(0)) return false;
            else{return true;}
        }

        public static bool[] Return(int amount, bool step){
            bool[] final = new bool[amount];
            for (int i = 0; i < amount; i++)
            {   
                if(step) final[i] = true;
                else{final[i] = false;}
            }
        return final;
        }
        public static int Min(bool[] res){
            int count = 0;
            for (int i = 0; i < res.Length; i++)
            {
                if (res[i] == true) count = count +1;
            }
            return count;
        }
        public static bool RespuestaValida(bool[] resp, bool[,] conv){
            int count = 0;
            for (int i = 0; i < resp.Length; i++)
            {
                 if (resp[i] == true) {
                     
                     count = count +1;
                     for (int k = 0; k < resp.Length; k++)
                     {
                         if (conv[i,k] == true && (k!=i) && !resp[k]) count = count +1;
                         if (count == resp.Length) return true;
                     }
                 }
            }
            if (count == resp.Length) return true;
            else {return false;}
        }
        }
    }



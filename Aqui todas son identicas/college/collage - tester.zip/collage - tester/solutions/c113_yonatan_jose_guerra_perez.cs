﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weboo.Examen
{
    public class Examenes
    {
        public static bool[] MinimoEstudio(bool[,] convalidaciones)
        {
            bool[] resultado = new bool[convalidaciones.GetLength(0)];
            for (int i = 0; i < resultado.Length; i++)
                resultado[i] = true;
            return MinimoEstudio(convalidaciones, new bool[convalidaciones.GetLength(0)], 0, resultado, new bool[convalidaciones.GetLength(0)]);
        }
        static bool IsFull(bool[] a)
        {
            foreach (bool s in a)
                if (!s)
                    return false;
            return true;
        }
        static bool[] MinimoEstudio(bool[,]convalidaciones,bool[] Aprobadas,int Asignaturas,bool[] resultado,bool[]resultado_obtenido)
        {
            if(IsFull(Aprobadas))
            {
                int MinimoAsignaturas = 0;
                foreach (bool s in resultado)
                    if (s)
                        MinimoAsignaturas++;
                if (Asignaturas <= MinimoAsignaturas)
                {
                    resultado = new bool[resultado.Length];
                    for(int i = 0; i < resultado_obtenido.Length; i++)
                    {
                        if (resultado_obtenido[i])
                            resultado[i] = true;
                        else
                            resultado[i] = false;
                    }
                }
                return resultado;
            }
            for(int i = 0; i < convalidaciones.GetLength(0);i++)
            {
                if (!Aprobadas[i])
                {
                    Aprobadas[i] = true;
                    resultado_obtenido[i] = true;
                    bool[] aprobadas = new bool[Aprobadas.Length];
                    for (int k = 0; k < aprobadas.Length; k++)
                        if (Aprobadas[k])
                            aprobadas[k] = true;
                    for(int j = 0; j < convalidaciones.GetLength(1); j++)
                    {
                        if (convalidaciones[i, j])
                            aprobadas[j] = true;
                    }
                    int poda = 0;
                    for (int j = 0; j < resultado.Length; j++)
                        if (resultado[j])
                            poda++;
                    if (Asignaturas + 1 >= poda)
                    {
                        resultado_obtenido[i] = false;
                        return resultado;
                    }
                    resultado = MinimoEstudio(convalidaciones, aprobadas, Asignaturas + 1, resultado,resultado_obtenido);
                    resultado_obtenido[i] = false;
                    Aprobadas[i] = false;
                }
            }
            return resultado;
        }
    }

}

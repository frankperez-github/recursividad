﻿namespace Weboo.Examen
{
    public class Examenes
    {

        public static bool[] MinimoEstudio(bool[,] convalidaciones, bool[] conva, int filas, int columnas, int ultima_pos, int cuenta, bool[] respuesta, int posf, int posc, List<Tuple<int, int>> deayuda, List<int> x, Dictionary<int, bool> b )
        {
            if (!Recorrido(convalidaciones, filas, columnas, ultima_pos, cuenta))
            {

                if (posf < filas)
                {

                    
                         if (!b.ContainsKey(posf) && convalidaciones[posf, posc])
                        {      b.Add(posf, true); }
                    
                    for (int i = 0; i < columnas; i++)
                    {

                        if ( convalidaciones[posf, i])
                        {   
                            
                             if (!b.ContainsKey(posf))
                             {
                                 b.Add(i, false);
                             }
            

                        }
                        cuenta++;
                        if (i == columnas - 1)
                        {   
                                    
                         MinimoEstudio(convalidaciones, conva, filas, columnas, ultima_pos, cuenta, respuesta, posf + 1, posc, deayuda,  x, b);
                        }

                    }


                }
                else
                {
                    if (posf+1 == filas)
                    {
                           int n = 0;
                          foreach (var item in b)
                            {   
                                respuesta[n] = item.Value;

                                n++;
                            }

                         return respuesta;
                          
                    }
                }



            }
            else
            {
                   int n = 0;
                          foreach (var item in b)
                            {   
                                respuesta[n] = item.Value;

                                n++;
                            }

                         return respuesta;
                          
            }


            return MinimoEstudio(convalidaciones, conva, filas, columnas, ultima_pos, cuenta, respuesta, posf, posc, deayuda, x, b);

        }

        private static bool Recorrido(bool[,] convalidaciones, int filas, int columnas, int ultima_pos, int cuenta)
        {

            if (cuenta == ultima_pos)
            {
                return true;
            }


            return false;
        }
    }

}

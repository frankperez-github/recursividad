﻿namespace Weboo.Examen
{
    public class Examenes
    {
        private static int globalMin;
        private static List<bool> globalMinConvalidado = new();

        public static bool[] MinimoEstudio(bool[,] convalidaciones)
        {
            globalMin = convalidaciones.GetLength(0) - 1;
            
            globalMinConvalidado = new();
            Fill(globalMinConvalidado, convalidaciones.GetLength(0), true);
            
            bool[] convalidado = new bool[convalidaciones.GetLength(0)];

            Minimo(convalidaciones, convalidado, 0);
            
            return globalMinConvalidado.ToArray();
        }

        private static void Minimo(bool[,] convalidaciones, bool[] convalidado, int n)
        {
            if (IsAllConvalidated(convalidaciones, convalidado) && convalidado.Count(elem => elem) < globalMin)
            {
                globalMin = convalidado.Count(elem => elem);
                globalMinConvalidado = convalidado.ToList();
                return;
            }

            if (n == convalidado.Length) return;

            if (globalMin == 1 || convalidado.Count(elem => elem) == globalMin) return;

            convalidado[n] = true;
            Minimo(convalidaciones, convalidado, n + 1);
            convalidado[n] = false;
            Minimo(convalidaciones, convalidado, n + 1);
        }

        private static bool IsAllConvalidated(bool[,] convalidaciones, bool[] convalidado)
        {
            bool[] newConvalidado = new bool[convalidado.Length];

            for (int i = 0; i < convalidado.Length; i++)
            {
                for (int j = 0; j < convalidado.Length; j++)
                {
                    if (convalidado[i] && convalidaciones[i, j]) newConvalidado[j] = true;
                }
            }

            return (newConvalidado.Count(elem => elem) == convalidado.Length) ? true : false;
        }

        private static void Fill(bool[] arr, bool value)
        {
            for (int i = 0; i < arr.Length; i++)
            {
                arr[i] = value;
            }
        }

        private static void Fill(List<bool> ls, int size, bool value)
        {
            for (int i = 0; i < size; i++)
            {
                ls.Add(value);
            }
        }
    }

}

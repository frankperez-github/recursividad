﻿using System.Data;
using System.Reflection.Metadata;
using System.Security.Cryptography.X509Certificates;
namespace Weboo.Examen
{
    public class Examenes
    {
        // Matriz Convalidacion Global
        public static bool[,] Convalid;
        // List MinAsinaturas
        public static List<bool> Minimo;
        // Cantidad de Asignaturas Tomadas
        public static int cant = 0;
        public static bool[] MinimoEstudio(bool[,] convalida)
        {
            int i = convalida.GetLength(0);
            // Vriables Globales
            Convalid =  new bool[i,i];
            Convalid = convalida;
            Minimo = new List<bool>();
            cant = int.MaxValue;
            // Llamado Recursivo
            MinAsinaturas(new bool[i],new bool[i]);
            return Minimo.ToArray();
        }
        public static void MinAsinaturas(bool[] maskAsignatura, bool[] rturnAsinatura)
        {
            // Si todas estan aprobadas
            if (IsTodasAprobadas(maskAsignatura))
            {   
                //Numero de asinaturas tomadas
                int min = MinAsina(rturnAsinatura);
                
                if(min < cant)
                {
                    Minimo.Clear();
                    Minimo.AddRange(rturnAsinatura);
                    cant = min;
                }
            }
            else
            {
                for (int i = 0; i < maskAsignatura.Length; i++)
                {
                    // Si No esta tomada
                    if (!maskAsignatura[i])
                    {
                        // Tomala
                        rturnAsinatura[i] = true;
                        MinAsinaturas(UpdateMask(rturnAsinatura), rturnAsinatura);
                        rturnAsinatura[i] = false;
                    }
                }
            }
        }

        public static bool[] UpdateMask(bool[] mask)
        {
            bool[] result = new bool[mask.Length];

            for (int i = 0; i < mask.Length; i++)
            {
                if (mask[i])
                {
                    result[i] = true;
                    UpdateVecinas(result, i);
                }

            }
            return result;
        }
        public static void UpdateVecinas(bool[] mask, int pos)
        {
            for (int i = 0; i < mask.Length; i++)
            {
                if (Convalid[pos, i])
                {
                    mask[i] = true;
                }
            }
        }
        public static bool IsTodasAprobadas(bool[] mask)
        {
            for (int i = 0; i < mask.Length; i++)
            {
                if (!mask[i]) return false;
            }
            return true;
        }

        public static int MinAsina(bool[] mask)
        {
            int result = 0;
            for(int i = 0; i < mask.Length; i++)
            {
                if(mask[i]) result++;
            }
            return result;
        }
    }

}

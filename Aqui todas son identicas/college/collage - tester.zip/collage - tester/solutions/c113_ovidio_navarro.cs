﻿namespace Weboo.Examen
{
    public class Examenes
    {
        public static bool[] MinimoEstudio(bool[,] convalidaciones)
        {
            // Borre esta línea y escriba su código
            //throw new NotImplementedException();
            int cant=convalidaciones.GetLength(0);
            bool[]resp=new bool[cant];
            ConjPotencia(cant);
            for(int k=0;k<Asignaturas.Count;k++){
                int count=0;
                bool[]Necesarias=new bool[convalidaciones.GetLength(0)];
                for(int i=0;i<Asignaturas[k].Length;i++){
                    for(int j=0;j<convalidaciones.GetLength(0);j++){
                        
                        if(convalidaciones[Asignaturas[k][i],j]){
                            Necesarias[j]=true;
                        }
                    }
                }
                for(int t=0;t<Necesarias.Length;t++){
                    if(Necesarias[t]){
                        count++;
                    }
                    if (count==Necesarias.Length){
                        for(int h=0;h<Asignaturas[k].Length;h++){
                            resp[Asignaturas[k][h]]=true;
                        }
                        Asignaturas.Clear();
                        return resp;
                       
                    }
                }
            }
                       
            return resp;
            
        }
        public static List<int[]>Asignaturas=new List<int[]>();
        static void ConjPotencia(int n){
            for (int m = 1; m <=n; m++)
            {
                Combinacion(n,m);
            }
        }
        static void Combinacion(int n,int m){
            Combinacion2(n,new int[m],0,0);
        }
        static void Combinacion2(int n,int []combinaciones,int cuantas,int menoraponer){
            if(cuantas==combinaciones.Length){
                var x=combinaciones.Clone();
                Asignaturas.Add((int[])x);
            }
            else{
                for(int k=menoraponer;k<n;k++){
                    combinaciones[cuantas]=k;
                    Combinacion2(n,combinaciones,cuantas+1,k+1);
                }
            }
        }
    }

}





﻿namespace Weboo.Examen
{
    public class Examenes
    {
        public static bool[] MinimoEstudio(bool[,] convalidaciones)
        {
            bool[] retorno = new bool[convalidaciones.GetLength(0)];
            if (noHayConvalidacion(convalidaciones))
            {
                for (int i = 0; i < retorno.Length; i++)
                {
                    retorno[i] = true;
                }
                return retorno;
            }
            return MinimoEstudio(convalidaciones, retorno, new bool[convalidaciones.GetLength(0)], 0);
        }
        private static bool[] MinimoEstudio(bool[,] convalidaciones,bool[]retorno, bool[]mask,int f )
        {
            if (f == convalidaciones.GetLength(0))
            {
               // comprobar(); //compruebo si repito alguna asignatura
                return retorno;
            }
           
            for (int c = 0; c < convalidaciones.GetLength(1); c++)
            {
                    if (c == f) continue;
                    if (convalidaciones[f, c] == true)
                    {
                        mask[c] = true;
                    }                  
            }

            if (algunaAsignaturaConvalidada(mask))
            { 
                if (MaskLLena(mask))
                {
                    vaciarMask(retorno);
                    retorno[f] = true;
                    f = convalidaciones.GetLength(0);
                    return retorno;
                }
                retorno[f] = true;
                vaciarMask(mask);
            }

            return MinimoEstudio(convalidaciones, retorno, mask, f + 1);
        
        }
        static bool noHayConvalidacion(bool[,]convalidaciones)
        {
            for (int i = 0; i < convalidaciones.GetLength(0); i++)
            {
                for (int j = 0; j < convalidaciones.GetLength(1); j++)
                {
                    if (j == i) continue;
                    if (convalidaciones[i, j])
                        return false;
                }
            }
            return true;
        }
        static bool algunaAsignaturaConvalidada(bool[]mask)
        {
            for (int i = 0; i < mask.Length; i++)
            {
                if(mask[i])
                    return true;
            }
            return false;
              
        }
        static void vaciarMask(bool[] mask)
        {
            for (int i = 0; i < mask.Length; i++)
            {
                if (mask[i])
                    mask[i]=false;
            }
        }
        static bool MaskLLena(bool[] mask)//comprueba si una asignatura convalida a todas
        {
            int cant = 0; 
            int cantConv= mask.Length-1;
            for (int i = 0; i < mask.Length; i++)
            {
                if (mask[i])
                    cant++;
            }
            if (cant == cantConv)
                return true;
            return false;
        }
        /*static void comprobar(bool[,]convalidaciones, bool[]retorno)
        {
            List<int> asignaturas = new List<int>();

            for (int i = 0; i <retorno.Length ; i++)
            {
                if(retorno[i])
                    asignaturas.Add(i);
            }
              
            
            for (int j = 0; j < convalidaciones.GetLength(1); j++)
            {
                for (int i = 0; i < asignaturas.Count; i++)
                {
                    if(convalidaciones[asignaturas[i],j])
                }
            }

        }*/
    }

}

﻿using System.Runtime.InteropServices.ComTypes;

namespace Weboo.Examen
{
 
    public class Examenes
    {
        public static int min;
        public static bool[] MinimoEstudio(bool[,] convalidaciones)
        {
            min = int.MaxValue;
            bool[] sol = new bool[convalidaciones.GetLength(0)];
            return MinimoEstudio(convalidaciones, sol,new bool[sol.Length],  0);
            
        }

        public static bool[] MinimoEstudio(bool[,] convalidaciones, bool[] sol, bool[] marks,  int k)
        {
            if (k == marks.Length)
            {
                int min_actual = CalcularMin(marks, marks.Length);
                if (min_actual < min  && Valido(marks,convalidaciones))
                {
                    min = min_actual;
                    for (int i = 0; i < sol.Length; i++)
                    {
                        sol[i] = marks[i];
                    }
                }
            }
            else
            {
                if (CalcularMin(marks, k) >= min) return sol;
                    marks[k] = false;
                    sol = MinimoEstudio(convalidaciones,  sol, marks, k + 1);

                    marks[k] = true;
                    sol = MinimoEstudio(convalidaciones, sol, marks, k + 1);
               
            }

            return sol;

        }

        public static int CalcularMin(bool [] sol, int k)
        {
            int count = 0;
            for (int i = 0; i < k; i++)
            {
                if (sol[i]) count++;
            }

            return count;
        }

        public static bool Valido(bool [] sol, bool[,] convalidaciones)
        {
            bool[] aux = new bool[convalidaciones.GetLength(1)];
            for (int i = 0; i < sol.Length; i++)
            {
                if (sol[i])
                {
                    for (int j = 0; j < convalidaciones.GetLength(1); j++)
                    {
                        if (convalidaciones[i, j])
                        {
                            aux[j] = true;
                        }
                    }
                }
            }

            for (int i = 0; i < aux.Length; i++)
            {
                if (!aux[i]) return false;
            }
            return true;
        }
    }
}

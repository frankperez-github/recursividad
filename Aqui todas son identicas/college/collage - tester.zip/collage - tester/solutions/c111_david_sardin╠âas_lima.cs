﻿namespace Weboo.Examen
{
    public class Examenes
    {

        static int minEst = 0;
        public static bool[] MinimoEstudio(bool[,] convalidaciones)
        {
            bool[] asignaturas_necesarias = new bool[convalidaciones.GetLength(0)]; //Creo un array con Dimensión igual a la cantidad de Asignaturas.

            minEst = convalidaciones.GetLength(0); // El menor número de asignaturas necesarias inicialmente es igual a la cantidad total de asignaturas.

            List<int>[] ListConvalida = new List<int>[convalidaciones.GetLength(0)]; //Crear un Array de List donde Los elementos de la List[i] son las asignaturas convalidadas por la asignatura "i".

            #region Llenar las listas de las asignaturas que cada asignatura convalida.

            for (int i = 0; i < convalidaciones.GetLength(0); i++)
            {
                for (int j = 0; j < convalidaciones.GetLength(1); j++)
                {
                    if (convalidaciones[i, j]) ListConvalida[i].Add(j); // Si la casilla está marcada con True entonces agregar el elemento a la lista.

                    asignaturas_necesarias[i] = true; //También se aprovecha el ciclo para rellenar el array de asignaturas necesarias(inicialmente todo en TRUE)
                }
            }

            #endregion


            return MinimoEstudio1(convalidaciones, 0, convalidaciones.GetLength(0), ListConvalida, asignaturas_necesarias);

        }


        public static bool[] MinimoEstudio1(bool[,] convalidaciones, int asignatura, int cant_asig, List<int>[] ListConvalida, bool[] AsigNecesarias)
        {
            bool[] asig_necesarias = ClonarArray(AsigNecesarias); //Clonamos el Array

            if (SeCumple(ListConvalida, asignatura)) //Verificamos si podemos eliminar una asignatura del plan de estudios
            {
                asig_necesarias[asignatura] = false; //Eliminada

                asig_necesarias = MinimoEstudio1(convalidaciones, asignatura+1, cant_asig, ListConvalida, asig_necesarias);
            }


            return asig_necesarias;
        }

        static bool SeCumple(List<int>[] ListConv, int AsigEliminar) //Verificar que si eliminamos una asignatura del plan de estudios, no se queda ninguna asignatura sin convalidar.
        {
            bool[] Convalidadas = new bool[ListConv.Length];

            for (int i = 0; i < ListConv.Length; i++) //Recorrer los elementos de cada lista
            {
                if(i == AsigEliminar) continue; //No revisar la List de la asignatura que queremos eliminar

                foreach (var item in ListConv[i])
                {
                    Convalidadas[item] = true; //Marcamos las asignaturas que son convalidadas según se van encontrando en las List
                }
            }

            for (int i = 0; i < Convalidadas.Length; i++) //Revisamos si no se quedó ninguna sin convalidar
            {
                if(Convalidadas[i]==false) return false;//si se encuentra una sin convalidar se retorna FALSE
            }
            return true; //...de lo contrario, si llegó a este punto entonces todas las asignaturas fueron cubierta y se retorna TRUE;

        }

        static bool[] ClonarArray(bool[] Array)
        {
            bool[] new_array = new bool[Array.Length];

            for (int i = 0; i < Array.Length; i++)
            {
                new_array[i] = Array[i];   
            }

            return new_array;
        }

        bool Convalida(bool[,] convalidaciones, int asig1, int asig2)
        {
            if (convalidaciones[asig1, asig2]) return true;

            return false;
        }
    }

}

﻿namespace Weboo.Examen
{
    public class Examenes
    {
        static bool var = false;
        static int combinaciones;
        public static bool[] MinimoEstudio(bool[,] convalidaciones)
        {
            bool[] materias = Casos(convalidaciones);
            if (var == true)
                materias = new bool[convalidaciones.GetLength(0)];

            List<int> X = new List<int>();

            combinaciones = materias.Length - 1;
            for (int i = 1; i < materias.Length; i++)
            {
                combinaciones--;

                X.Add(Materias(convalidaciones, new int[materias.Length], new List<int>(), 0, new bool[materias.Length]).Min());

            }
            for (int i = 0; i < X.Min(); i++)
            {
                materias[i] = true;
            }

            return materias;
        }
        static int[] Materias(bool[,] convalidaciones, int[] materias, List<int> sum, int asignatura, bool[] var)
        {
            if (sum.Count == materias.Length)
            {
                int index = 0;

                for (int i = materias.Length - 1; i <= 0; i--)
                {
                    if (var[i] == true)
                    {
                        index = i;
                        break;
                    }
                }
                materias[index] = asignatura;

                return materias;
            }
            if (asignatura == combinaciones)
            {
                return materias;
            }

            for (int i = 0; i < materias.Length; i++)
            {
                if (var[i] == false)
                {
                    sum = Convalidar(convalidaciones, i, sum);
                    materias[i] += 1;
                    var[i] = true;

                    if (sum.Count < materias.Length)
                        materias = Materias(convalidaciones, materias, sum, asignatura + 1, var);

                    else materias = Materias(convalidaciones, materias, sum, asignatura + 1, var);

                    var[i] = false;
                    materias[i] -= 1;
                }
            }
            return materias;
        }
        static bool[] Casos(bool[,] convalidaciones)
        {
            bool[] materias = new bool[convalidaciones.GetLength(0)];

            int count = 0;
            for (int i = 0; i < convalidaciones.GetLength(0); i++)
            {
                int count1 = 0;
                for (int j = 0; j < convalidaciones.GetLength(0); j++)
                {
                    if (convalidaciones[i, j] == true)
                    {
                        count++;
                        count1++;
                    }
                }
                if (count1 == convalidaciones.GetLength(0)) materias[i] = true;
            }
            if (materias.Contains(true)) return materias;

            if (count == convalidaciones.GetLength(0))
            {
                for (int i = 0; i < materias.Length; i++)
                {
                    materias[i] = true;
                }
                return materias;
            }
            else
            {
                var = true;
                return materias;
            }
        }
        static List<int> Convalidar(bool[,] convalidaciones, int materia, List<int> count)
        {
            for (int i = 0; i < convalidaciones.GetLength(0); i++)
            {
                if (convalidaciones[materia, i] == true && count.Contains(i) == false)
                {
                    count.Add(i);
                }
            }
            return count;
        }
    }
}
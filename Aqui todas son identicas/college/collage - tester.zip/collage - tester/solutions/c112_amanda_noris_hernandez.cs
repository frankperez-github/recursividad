﻿namespace Weboo.Examen
{
    public class Examenes
    {
        public static bool[] MinimoEstudio(bool[,] convalidaciones)
        {

            return Estudio(convalidaciones, 0, new bool[convalidaciones.GetLength(0)], 0, 0, new bool[convalidaciones.GetLength(0)]).Item2;
        }

        private static (int,bool[]) Estudio(bool[,] convalidaciones, int index, bool[] mask, int cantAsignaturas, int cantConvalidadas, bool[] asignaturas)
        {
          if(index == mask.Length)
          return (cantAsignaturas, asignaturas);

          int min = int.MaxValue;
          bool[] solution = null;

         for (int i = 0; i < mask.Length; i++)
         {
            if(mask[i] || !ConvalidaAlgoNuevo(convalidaciones,index, mask)) continue;

            mask[i] = true;
            asignaturas[index] = true;

            (int, bool[]) sol1 = Estudio(convalidaciones, index +1, mask, cantAsignaturas +1, cantConvalidadas, asignaturas);

            mask[i] = false;
            
            if(min > sol1.Item1) 
            {
               min = sol1.Item1;
               solution = (bool[])(sol1.Item2).Clone();
            }

         }

            (int, bool[]) sol2 = Estudio(convalidaciones, index +1, mask, cantAsignaturas, cantConvalidadas, asignaturas);
 
            if(min > sol2.Item1 )
            {
                min =  sol2.Item1;
                solution = (bool[])(sol2.Item2).Clone();
            }

//Console.WriteLine(cantAsignaturas);
            
          
          return (min, solution);
        }

        private static bool ConvalidaAlgoNuevo(bool[,] convalidaciones, int index, bool[] mask)
        {
           for (int i = 0; i < mask.Length; i++)
           {
               if(convalidaciones[index, i] && !mask[i]) return true;
           }

           return false;
        }

       /* private static (int,bool[]) Estudio(bool[,] convalidaciones, int index, bool[] mask, int[] asignaturas, int cantAsignaturas, int cantConvalidadas)
        {
          if(index == asignaturas.Length)
          return (cantAsignaturas, mask);

          int min = int.MaxValue;
          bool[] solution = null;

         for (int i = 0; i < asignaturas.Length; i++)
         {
            if(mask[i]) continue;

            mask[i] = true;
            (int, bool[]) sol1 = Estudio(convalidaciones, index +1, mask, asignaturas, cantAsignaturas +1, cantConvalidadas +asignaturas[index]);
            mask[i] = false;

            if(min> sol1.Item1) min = sol1.Item1;
            solution = (bool[])mask.Clone();

         }

            //(int, bool[]) sol2 = Estudio(convalidaciones, index +1, mask, asignaturas, cantAsignaturas, cantConvalidadas);
            //if(min > sol2.Item1 )
            //min =  sol2.Item1;

            solution = (bool[])mask.Clone();

//Console.WriteLine(min);
          
          return (min, solution);
        }

        private static int[] Conv(bool[,] convalidaciones)
        {
            int[] sol = new int [convalidaciones.GetLength(0)];
            for (int i = 0; i < sol.Length; i++)
            {
                //crea un array con la cantidad de asignaturas que convalida cada asignatura
                sol[i] = Convalida(convalidaciones, i);
//Console.WriteLine(sol[i]);
            }

             return sol;
        }*/

        private static int Convalida (bool[,] convalidaciones, int index)
        {
           int count = 0;

           //cuenta cuantas asignaturas convalida cada asignatura
           for (int i = 0; i < convalidaciones.GetLength(1); i++)
           {
               if(convalidaciones[index, i]) count ++;
           }

//Console.WriteLine(count);

           return count;

        }

        /*private static (int,bool[]) Estudio(bool[,] convalidaciones, int index, bool[] asignaturas, int cantConvalidadas)
        {
          if(index == convalidaciones.GetLength(0) -1)
          return (cantConvalidadas, asignaturas);

          int max = int.MinValue;

          for (int i = 1; i < asignaturas.Length; i++)
          {
              if(asignaturas[i]) continue;

              asignaturas[i] = true;
              (int, bool[]) sol1 = Estudio(convalidaciones, index +1, asignaturas, cantConvalidadas + Convalida(convalidaciones, index));
              asignaturas[i] = false;

              if(max < sol1.Item1) max = sol1.Item1;

          }

          
          (int, bool[]) sol2 = Estudio(convalidaciones, index +1, asignaturas, cantConvalidadas);
          
          cantConvalidadas = Math.Max(sol2.Item1, max);

          return (cantConvalidadas, asignaturas);

        }*/

        /*private static (int,bool[]) Estudio(bool[,] convalidaciones, int index, bool[] asignaturas, int cantConvalidadas)
        {
          if(index == convalidaciones.GetLength(0) -1)
          return (cantConvalidadas, asignaturas);

          bool[] asig = null;
          int min = int.MaxValue;

          for (int i = 0; i < asignaturas.Length; i++)
          {
              if(asignaturas[i]) continue;

              asignaturas[i] = true;
              (int, bool[]) sol = Estudio(convalidaciones, index +1, asignaturas, cantConvalidadas +1);
              asignaturas[i] = false;

            if(cantConvalidadas > min)
            cantConvalidadas = min;

          }

          return (cantConvalidadas, asignaturas);

        }*/
    }

}

﻿//Solucion mala que funciona
/*using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weboo.Examen
{
    public class Examenes
    {
        private static void PrintArrayBool(bool[] a)
        {
//Console.Write(" }");
            for (int i = 0; i < a.Length; i++)
            {
//Console.Write(" " + a[i] + " ");
            }
//Console.Write(" }");
//Console.WriteLine();
        }
        private static int CuantasPuedeConvalidar(bool[,] matrix)
        {
            int count = 0;
            for (int i = 0; i < matrix.GetLength(1); i++)
            {
                for (int j = 0; j < matrix.GetLength(0); j++)
                {
                    //if (i == j) continue;
                    if (matrix[j, i])
                    {
                        count++;
                        continue;
                    }
                }
            }
//Console.WriteLine("cant de convalidadas: " + count);
            return count;
        }
        private static bool EsSolucion(bool[] mascaraDeAsignaturas, bool[,] convalidaciones)
        {
            int c = 0;
            bool[,] conceptualMap = new bool[convalidaciones.GetLength(0), convalidaciones.GetLength(1)];
            for (int i = 0; i < mascaraDeAsignaturas.Length; i++)
            {
                if (mascaraDeAsignaturas[i])
                {
                    for (int j = 0; j < convalidaciones.GetLength(1); j++)
                    {
                        if (convalidaciones[i, j]) conceptualMap[i, j] = true;
                    }
                }
            }
            c = CuantasPuedeConvalidar(conceptualMap);
            if (c == mascaraDeAsignaturas.Length) return true;
            return false;
        }
        public static bool[] MinimoEstudio(bool[,] convalidaciones)
        {
            bool[] mascaraDeAsignaturas = new bool[convalidaciones.GetLength(0)];
            bool[] resp = new bool[convalidaciones.GetLength(0)];
            for (int i = 1; i <= mascaraDeAsignaturas.Length; i++)
            {
                Generar(mascaraDeAsignaturas, convalidaciones, i, 0);
                if (EsSolucion(resp, convalidaciones))
                {
                    PrintArrayBool(resp);
                    return resp;
                }
            }
            return (new bool[mascaraDeAsignaturas.Length]);
//Console.WriteLine("aaaa");
        }
        private static void Generar(bool[] mascaraDeAsignaturas, bool[,] convalidaciones, int n, int puesta)
        {
            if ((puesta == n))
            {
                if (EsSolucion(mascaraDeAsignaturas, convalidaciones)) PrintArrayBool(mascaraDeAsignaturas);
                return;
            }
            else
                for (int i = 0; i < mascaraDeAsignaturas.Length; i++)
                {
                    if (!mascaraDeAsignaturas[i])
                    {
                        mascaraDeAsignaturas[i] = true;
                        Generar(mascaraDeAsignaturas, convalidaciones, n, puesta + 1);
                        mascaraDeAsignaturas[i] = false;
                    }
                }
            //return new bool[1];
        }
    }

}
*/
//probar encontrar unas solucion que devuelva lo que piden los profesores

//solucion con errores arreglados
//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace Weboo.Examen
//{
//    public class Examenes
//    {
//        private static void PrintArrayBool(bool[] a)
//        {
//Console.Write(" }");
//            for (int i = 0; i < a.Length; i++)
//            {
//Console.Write(" " + a[i] + " ");
//            }
//Console.Write(" }");
//Console.WriteLine();
//        }
//        private static int CuantasPuedeConvalidar(bool[,] matrix)
//        {
//            int count = 0;
//            for (int i = 0; i < matrix.GetLength(1); i++)
//            {
//                for (int j = 0; j < matrix.GetLength(0); j++)
//                {
//                    //if (i == j) continue;
//                    if (matrix[j, i])
//                    {
//                        count++;
//                        break;
//                    }
//                }
//            }
//Console.WriteLine("cant de convalidadas: " + count);
//            return count;
//        }
//        private static bool EsSolucion(bool[] mascaraDeAsignaturas, bool[,] convalidaciones)
//        {
//            int c = 0;
//            bool[,] conceptualMap = new bool[convalidaciones.GetLength(0), convalidaciones.GetLength(1)];
//            for (int i = 0; i < mascaraDeAsignaturas.Length; i++)
//            {
//                if (mascaraDeAsignaturas[i])
//                {
//                    for (int j = 0; j < convalidaciones.GetLength(1); j++)
//                    {
//                        if (convalidaciones[i, j]) conceptualMap[i, j] = true;
//                    }
//                }
//            }
//            c = CuantasPuedeConvalidar(conceptualMap);
//            if (c == mascaraDeAsignaturas.Length) return true;
//            return false;
//        }
//        private static bool[] mascaraDeAsignaturas;
//        public static bool[] MinimoEstudio(bool[,] convalidaciones)
//        {
//            // bool[] mascaraDeAsignaturas = new bool[convalidaciones.GetLength(0)];
//            mascaraDeAsignaturas = new bool[convalidaciones.GetLength(0)];
//            bool[] resp = new bool[convalidaciones.GetLength(0)];
//            for (int i = 1; i <= resp.Length; i++)
//            {
//                Generar(ref mascaraDeAsignaturas, convalidaciones, i, 0);
//                if (EsSolucion(mascaraDeAsignaturas, convalidaciones))
//                {
//                    PrintArrayBool(mascaraDeAsignaturas);
//                    return mascaraDeAsignaturas;
//                }
//            }
//            return (new bool[resp.Length]);
//Console.WriteLine("aaaa");
//        }
//        private static void Generar(ref bool[] mascaraDeAsignaturas, bool[,] convalidaciones, int n, int puesta)
//        {
//            if ((puesta == n))
//            {
//                if (EsSolucion(mascaraDeAsignaturas, convalidaciones)) PrintArrayBool(mascaraDeAsignaturas);
//                return;
//            }
//            else
//                for (int i = 0; i < mascaraDeAsignaturas.Length; i++)
//                {
//                    if (!mascaraDeAsignaturas[i])
//                    {
//                        mascaraDeAsignaturas[i] = true;
//                        Generar(ref mascaraDeAsignaturas, convalidaciones, n, puesta + 1);
//                        mascaraDeAsignaturas[i] = false;
//                    }
//                }
//            //return new bool[1];
//        }
//    }

//}
//experimentar para devolver el numero

//acercándonos a una buena solucion

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weboo.Examen
{
    public class Examenes
    {
        private static void PrintArrayBool(bool[] a)
        {
//Console.Write(" }");
            for (int i = 0; i < a.Length; i++)
            {
//Console.Write(" " + a[i] + " ");
            }
//Console.Write(" }");
//Console.WriteLine();
        }
        private static int CuantasPuedeConvalidar(bool[,] matrix)
        {
            int count = 0;
            for (int i = 0; i < matrix.GetLength(1); i++)
            {
                for (int j = 0; j < matrix.GetLength(0); j++)
                {
                    //if (i == j) continue;
                    if (matrix[j, i])
                    {
                        count++;
                        break;
                    }
                }
            }
//Console.WriteLine("cant de convalidadas: " + count);
            return count;
        }
        private static bool EsSolucion(bool[] mascaraDeAsignaturas, bool[,] convalidaciones)
        {
            int c = 0;
            bool[,] conceptualMap = new bool[convalidaciones.GetLength(0), convalidaciones.GetLength(1)];
            for (int i = 0; i < mascaraDeAsignaturas.Length; i++)
            {
                if (mascaraDeAsignaturas[i])
                {
                    for (int j = 0; j < convalidaciones.GetLength(1); j++)
                    {
                        if (convalidaciones[i, j]) conceptualMap[i, j] = true;
                    }
                }
            }
            c = CuantasPuedeConvalidar(conceptualMap);
            if (c == mascaraDeAsignaturas.Length) return true;
            return false;
        }
        private static bool[] mascaraDeAsignaturas;
        public static bool[] MinimoEstudio(bool[,] convalidaciones)
        {
            // bool[] mascaraDeAsignaturas = new bool[convalidaciones.GetLength(0)];
            bool flag = false;
            bool isSol=false;
            mascaraDeAsignaturas = new bool[convalidaciones.GetLength(0)];
            bool[] resp = new bool[convalidaciones.GetLength(0)];
            for (int i = 1; i <= resp.Length; i++)
            {
                if (!flag)
                {
                    Generar(ref mascaraDeAsignaturas, convalidaciones, i, 0, ref flag);
                    if (EsSolucion(mascaraDeAsignaturas, convalidaciones))
                    {
                        PrintArrayBool(mascaraDeAsignaturas);
                        return mascaraDeAsignaturas;
                    }
                }
            }
            return (new bool[resp.Length]);
//Console.WriteLine("aaaa");
        }
        private static void Generar(ref bool[] mascaraDeAsignaturas, bool[,] convalidaciones, int n, int puesta, ref bool flag)
        {
            if (!flag)
            {
                if ((puesta == n))
                {
                    if (EsSolucion(mascaraDeAsignaturas, convalidaciones))
                    {
                        PrintArrayBool(mascaraDeAsignaturas);
                        flag = true;
                    }
                    return;
                }
                else
                    for (int i = 0; i < mascaraDeAsignaturas.Length; i++)
                    {
                        if (!mascaraDeAsignaturas[i])
                        {
                            mascaraDeAsignaturas[i] = true;
                            Generar(ref mascaraDeAsignaturas, convalidaciones, n, puesta + 1, ref flag);
                            mascaraDeAsignaturas[i] = false;
                        }
                    }

            }
            //return new bool[1];
        }
    }

}


//tratar de llegar a la buena solucion

/*using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weboo.Examen
{
    public class Examenes
    {
        private static new List<bool[]> Solucion = new List<bool[]>();
        private static bool[] ssss;
        private static void PrintArrayBool(bool[] a)
        {
//Console.Write(" }");
            for (int i = 0; i < a.Length; i++)
            {
//Console.Write(" " + a[i] + " ");
            }
//Console.Write(" }");
//Console.WriteLine();
        }
        private static int CuantasPuedeConvalidar(bool[,] matrix)
        {
            int count = 0;
            for (int i = 0; i < matrix.GetLength(1); i++)
            {
                for (int j = 0; j < matrix.GetLength(0); j++)
                {
                    //if (i == j) continue;
                    if (matrix[j, i])
                    {
                        count++;
                        break;
                    }
                }
            }
//Console.WriteLine("cant de convalidadas: " + count);
            return count;
        }
        private static bool EsSolucion(bool[] mascaraDeAsignaturas, bool[,] convalidaciones)
        {
            int c = 0;
            bool[,] conceptualMap = new bool[convalidaciones.GetLength(0), convalidaciones.GetLength(1)];
            for (int i = 0; i < mascaraDeAsignaturas.Length; i++)
            {
                if (mascaraDeAsignaturas[i])
                {
                    for (int j = 0; j < convalidaciones.GetLength(1); j++)
                    {
                        if (convalidaciones[i, j]) conceptualMap[i, j] = true;
                    }
                }
            }
            c = CuantasPuedeConvalidar(conceptualMap);
            if (c == mascaraDeAsignaturas.Length) return true;
            return false;
        }
        private static bool[] mascaraDeAsignaturas;
        public static bool[] MinimoEstudio(bool[,] convalidaciones)
        {
            // bool[] mascaraDeAsignaturas = new bool[convalidaciones.GetLength(0)];
            bool flag = false;
            mascaraDeAsignaturas = new bool[convalidaciones.GetLength(0)];
            bool[] resp = new bool[convalidaciones.GetLength(0)];
            for (int i = 1; i <= resp.Length; i++)
            {
                if (!flag)
                {
                    Generar(ref mascaraDeAsignaturas, convalidaciones, i, 0, ref flag);
                    if (EsSolucion(Solucion[0], convalidaciones))
                    {
                        PrintArrayBool(Solucion[0]);
                        return Solucion[0];
                    }
                }
            }
            return (new bool[resp.Length]);
//Console.WriteLine("aaaa");
        }
        private static void Generar(ref bool[] mascaraDeAsignaturas, bool[,] convalidaciones, int n, int puesta, ref bool flag)
        {
            if (!flag)
            {
                if ((puesta == n))
                {
                    if (EsSolucion(mascaraDeAsignaturas, convalidaciones))
                    {
                        PrintArrayBool(mascaraDeAsignaturas);
                        flag = true;
                        ssss = new bool[mascaraDeAsignaturas.Length];
                        Array.Copy(mascaraDeAsignaturas, ssss, ssss.Length);
                        Solucion.Add(ssss);
                    }
                    return;
                }
                else
                    for (int i = 0; i < mascaraDeAsignaturas.Length; i++)
                    {
                        if (!mascaraDeAsignaturas[i])
                        {
                            mascaraDeAsignaturas[i] = true;
                            Generar(ref mascaraDeAsignaturas, convalidaciones, n, puesta + 1, ref flag);
                            mascaraDeAsignaturas[i] = false;
                        }
                    }

            }
            //return new bool[1];
        }
    }

}
*/
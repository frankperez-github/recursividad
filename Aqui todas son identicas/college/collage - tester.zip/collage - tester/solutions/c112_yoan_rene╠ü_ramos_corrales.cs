﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weboo.Examen
{
    public class Examenes
    {
        public static bool[] MinimoEstudio(bool[,] convalidaciones)
        {
            int min = convalidaciones.GetLength(0);
            Dictionary<int, List<int>> grafo = ConvertirAGrafo(convalidaciones);
            bool[] guardado = new bool[convalidaciones.GetLength(0)];
            PonerTodosEnTrue(guardado);
            MinimoEstudio_(grafo, ref min, guardado, new bool[convalidaciones.GetLength(0)], 0, 0);
            return guardado;
        }
        public static void MinimoEstudio_(Dictionary<int, List<int>> grafo, ref int min, bool[] guardado, bool[] conjPotencia, int index, int cantDeAsignaturasACursar)
        {
            if (index == conjPotencia.Length)
            {
                if (TodasEstanAprobadas(grafo, conjPotencia) && min > cantDeAsignaturasACursar)
                {
                    min = cantDeAsignaturasACursar;
                    Array.Copy(conjPotencia, guardado, conjPotencia.Length);
                }
            }
            else
            {
                conjPotencia[index] = false;
                MinimoEstudio_(grafo, ref min, guardado, conjPotencia, index + 1, cantDeAsignaturasACursar);
                conjPotencia[index] = true;
                MinimoEstudio_(grafo, ref min, guardado, conjPotencia, index + 1, cantDeAsignaturasACursar + 1);
            }
        }
        public static bool TodasEstanAprobadas(Dictionary<int, List<int>> grafo, bool[] conjPotencia)
        {
            bool[] aprobadas = new bool[conjPotencia.Length];
            foreach (var v in grafo)
                if (conjPotencia[v.Key])
                    foreach (var i in v.Value)
                        aprobadas[i] = true;
            for (int i = 0; i < aprobadas.Length; i++)
                if (!aprobadas[i])
                    return false;
            return true;
        }
        public static void PonerTodosEnTrue(bool[] guardado)
        {
            for (int i = 0; i < guardado.Length; i++)
                guardado[i] = true;
        }
        public static Dictionary<int, List<int>> ConvertirAGrafo(bool[,] convalidaciones)
        {
            Dictionary<int, List<int>> grafo = new Dictionary<int, List<int>>();
            for (int i = 0; i < convalidaciones.GetLength(0); i++)
                for (int j = 0; j < convalidaciones.GetLength(1); j++)
                    if (convalidaciones[i, j])
                    {
                        if (!grafo.ContainsKey(i))
                            grafo.Add(i, new List<int>());
                        grafo[i].Add(j);
                    }
            return grafo;
        }
    }
}
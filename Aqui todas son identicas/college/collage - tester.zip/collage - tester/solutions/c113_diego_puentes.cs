﻿namespace Weboo.Examen
{
    public class Examenes
    {
        public static bool[] MinimoEstudio(bool[,] convalidaciones)
        {
            bool[] result = new bool[convalidaciones.GetLength(0)];
            int count = 0;
            for (int i = 0; i < convalidaciones.GetLength(0); i++)
            {
                for (int j = 0; j < convalidaciones.GetLength(1); j++)
                {
                    if (convalidaciones[i, j] == true) count++;
                }
            }
            if (count == convalidaciones.GetLength(0))
            {
                for (int o = 0; o < result.GetLength(0); o++)
                {
                    result[o] = true;
                }
                return result;
            }
            Dictionary<int, List<int>> nexo = Nexo(convalidaciones);
            foreach (int h in nexo.Keys)
            {
                if (nexo[h].Count == convalidaciones.GetLength(0) +1)
                {
                    result[h] = true;
                    return result;
                }
            }
            Solucion(convalidaciones, nexo, result);
            return result;
        }
        public static Dictionary<int, List<int>> Nexo(bool[,] convalidaciones)
        {
            Dictionary<int, List<int>> nexo = new Dictionary<int, List<int>>();
            for (int i = 0; i < convalidaciones.GetLength(1); i++)
            {
                List<int> lista = new List<int>();
                for (int j = 0; j < convalidaciones.GetLength(0); j++)
                {
                    if (convalidaciones[i, j] == true)
                    {
                        lista.Add(j);
                    }
                }
                nexo.Add(i, lista);
            }
            return nexo;
        }
        public static void Solucion(bool[,] convalidaciones, Dictionary<int, List<int>> nexo, bool[] solucion)
        {
            int a = 0;
            int b = -1;
            foreach (var i in nexo.Keys)
            {
                if (nexo[i].Count > b) a = i;
                b = nexo[i].Count;
            }
            solucion[a] = true;
            foreach (int j in nexo[a])
            {
                nexo.Remove(j);
            }
            nexo.Remove(a);
            if (nexo.Keys.Count == 0) return;
            else
            {
                Solucion(convalidaciones, nexo, solucion);
            }
        }
    }
}

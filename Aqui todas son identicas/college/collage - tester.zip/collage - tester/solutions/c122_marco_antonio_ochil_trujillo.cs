﻿namespace Weboo.Examen
{
    public class Examenes
    {
        public static bool[] MinimoEstudio(bool[,] convalidaciones)
        {
            Dictionary<int, int[]> Convalida = new Dictionary<int, int[]>();
            Dictionary<int, int[]> MeConvalida = new Dictionary<int, int[]>();
            bool[] asignaturas = new bool[convalidaciones.GetLength(0)];
            List<int> marcados = new List<int>();

            for (int i = 0; i < convalidaciones.GetLength(0); i++)
            {
                List<int> countC = new List<int>();
                List<int> countMC = Posicion(convalidaciones, i);

                if (countMC.Count != 0)
                {
                    int[] real = countMC.ToArray();                    
                    MeConvalida.Add(i, real);                    
                }

                for (int j = 0; j < convalidaciones.GetLength(1); j++)
                {
                    if (convalidaciones[i, j] && i != j)
                    {
                        countC.Add(j);
                    }                    
                }

                if (countC.Count != 0)
                {
                    int[] use = countC.ToArray();
                    Convalida.Add(i, use);
                }

                countC.Clear(); 
            }

            if (Convalida.Count == 0)
            {
                return Realizar(convalidaciones.GetLength(0));
            }

            (bool[], List<int>) mark = Obligate(Convalida, MeConvalida, asignaturas, marcados);
            bool[] aprobadas = Marked(mark.Item2, asignaturas.Length);
            
            return CalculoReal(convalidaciones, Convalida, mark.Item1, aprobadas, mark.Item2, 0);
        }

        public static bool[] CalculoReal(bool[,] convalidaciones, Dictionary<int, int[]> Convalida, bool[] asignaturas, bool[] aprobadas, List<int> marcados, int index)
        {
            if (!aprobadas.Contains(false))
            {
                return asignaturas;
            }
            if (index == aprobadas.Length)
            {
                return Realizar(convalidaciones.GetLength(0));
            }

            if (!asignaturas[index])
            {
                List<int> No1 = new List<int>();
                asignaturas[index] = true;
                aprobadas[index] = true;

                if (Convalida.Keys.Contains(index))
                {
                    foreach (var asignatura in Convalida[index])
                    {
                        if (aprobadas[asignatura])
                        {
                            No1.Add(asignatura);
                            continue;
                        }

                        marcados.Add(asignatura);
                        aprobadas[asignatura] = true;
                    }
                }
            
                bool[] temp1 = (bool[]) CalculoReal(convalidaciones, Convalida, asignaturas, aprobadas, marcados, index + 1).Clone();
                int count1 = Contador(temp1);

                asignaturas[index] = false;

                if (!marcados.Contains(index))
                {
                    aprobadas[index] = false;
                }
                if (Convalida.Keys.Contains(index))
                {
                    foreach (var asignatura in Convalida[index])
                    {
                        if (No1.Contains(asignatura))
                        {
                            continue;
                        }
                        aprobadas[asignatura] = false;
                        marcados.Remove(asignatura);
                    }    
                }

                No1.Clear();
                bool[] temp2 = CalculoReal(convalidaciones, Convalida, asignaturas, aprobadas, marcados, index + 1);
                int count2 = Contador(temp2);

                bool[] result = (count1 > count2) ? temp2 : temp1;

                return result;                
            }

            return CalculoReal(convalidaciones, Convalida, asignaturas, aprobadas, marcados, index + 1);
        }

        public static List<int> Posicion(bool[,] convalidaciones, int asignatura)
        {
            List<int> utiles = new List<int>();

            for (int i = 0; i < convalidaciones.GetLength(0); i++)
            {
                if (convalidaciones[i, asignatura] && i != asignatura)
                {
                    utiles.Add(i);
                }
            }

            return utiles;
        }

        public static bool[] Realizar(int tam)
        {
            bool[] asignaturas = new bool[tam];
            
            for (int i = 0; i < tam; i++)
            {
                asignaturas[i] = true;
            }

            return asignaturas;
        }

        public static int Contador(bool[] asignaturas)
        {
            int count = 0;

            foreach (var asign in asignaturas)
            {
                if (asign)
                {
                    count++;
                }
            }

            return count;
        }

        public static (bool[], List<int>) Obligate(Dictionary<int, int[]> Convalida, Dictionary<int, int[]> MeConvalida, bool[] asignaturas, List<int> marcados)
        {
            for (int i = 0; i < asignaturas.Length; i++)
            {
                if (!MeConvalida.Keys.Contains(i))
                {
                    asignaturas[i] = true;
                    if (!marcados.Contains(i))
                    {
                        marcados.Add(i);
                    }

                    if (Convalida.Keys.Contains(i))
                    {
                        foreach (var item in Convalida[i])
                        {
                            if (!marcados.Contains(item))
                            {
                                marcados.Add(item);
                            }
                        }  
                    }                    
                }
            }

            return (asignaturas, marcados);
        }

        public static bool[] Marked(List<int> marcados, int tam)
        {
            bool[] aprobadas = new bool[tam];
            foreach (var item in marcados)        
            {
                aprobadas[item] = true;
            }

            return aprobadas;
        }
    }

}

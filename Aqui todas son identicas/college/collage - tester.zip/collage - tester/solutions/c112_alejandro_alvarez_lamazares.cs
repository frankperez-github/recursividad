﻿using System.ComponentModel;
using System.Runtime.Serialization;
namespace Weboo.Examen
{
    public class Examenes
    {
        public static bool[] MinimoEstudio(bool[,] convalidaciones)
        {
            return MinimoEstudio(convalidaciones, new bool[convalidaciones.GetLength(0)], 0, TodosEnTrue(new bool[convalidaciones.GetLength(0)]));
        }
        public static bool[] MinimoEstudio(bool[,] convalidaciones, bool[] variaciones, int index, bool[] best)
        {
            if (index == variaciones.Length && EsVálido(convalidaciones, best))
            {
                return best;
            }
            if (index == convalidaciones.GetLength(0)) return TodosEnTrue(new bool[convalidaciones.GetLength(0)]);
            //if (index == convalidaciones.GetLength(0)) return best;

            bool[] clon = new bool[variaciones.Length];
            for (var i = 0; i < 2; i++)
            {
                Array.Copy(best, clon, variaciones.Length);
                if (i == 0) clon[index] = false;
                else clon[index] = true;
                Array.Copy(MinimoEstudio(convalidaciones, variaciones, index + 1, clon), clon, variaciones.Length);


                if (EsVálido(convalidaciones, clon))
                {
                    if (EsVálido(convalidaciones, best))
                    {
                        if (EsMejor(clon, best))
                        {
                            Array.Copy(clon, best, clon.Length);

                        }
                        continue;

                    }
                    else Array.Copy(clon, best, clon.Length);
                }



            }
            return best;
        }
        public static void Imprime(bool[] a)
        {
            for (var i = 0; i < a.Length; i++)
            {
//Console.Write(a[i] + " ");
//Console.WriteLine(" ");
            }
        }
        public static bool EsVálido(bool[,] convalidaciones, bool[] variaciones)
        {
            bool[] asignaturas = new bool[variaciones.Length];
            for (var i = 0; i < variaciones.Length; i++)
            {
                if (variaciones[i])
                {
                    for (var j = 0; j < variaciones.Length; j++)
                    {
                        if (convalidaciones[i, j])
                        {
                            asignaturas[j] = true;
                        }
                    }
                }
            }
            for (var k = 0; k < asignaturas.Length; k++)
            {
                if (!asignaturas[k]) return false;

            }
            return true;
        }
        public static bool EsMejor(bool[] a, bool[] b) // mejor a que b
        {
            int vala = 0;
            int valb = 0;
            for (var i = 0; i < a.Length; i++)
            {
                if (a[i]) vala++;
                if (b[i]) valb++;
            }
            if (vala < valb) return true;
            return false;
        }

        public static bool[] TodosEnTrue(bool[] a)
        {
            for (var i = 0; i < a.Length; i++)
            {
                a[i] = true;
            }
            return a;
        }
    }

}

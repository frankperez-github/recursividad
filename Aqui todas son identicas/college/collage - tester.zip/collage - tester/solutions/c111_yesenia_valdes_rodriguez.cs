﻿namespace Weboo.Examen
{
    public class Examenes
    {
        public static bool[] MinimoEstudio(bool[,] convalidaciones)
        {
            int i = 0;
            List<int[]> asignaturas = new();
            List<int> cantidad = new();

            while (i < convalidaciones.GetLength(0))
            {
                int j = 0;
                var res = Aprov(convalidaciones, i, j);

                if (res.aprov[0] == -1)
                {
                    res.aprov[0] = i;
                }

                asignaturas.Add(res.aprov);
                cantidad.Add(res.cant);
                i++;
            }

            var res0 = Actuales(cantidad, asignaturas);
            var actual1 = res0.actual1;
            var actual2 = res0.actual2;
            bool[] respuesta = new bool[convalidaciones.GetLength(0)];
            int[] toremove = new int[convalidaciones.GetLength(0)];

            for (int h = 0; h < toremove.Length; h++)
            {
                toremove[h] = -1;
            }

            var res1 = Regress(cantidad, asignaturas, actual1, actual2, respuesta, toremove);
            return res1;

        }

        static (int[] aprov, int cant) Aprov(bool[,] convalidaciones, int i, int j)
        {
            int[] aprov = new int[convalidaciones.GetLength(0)];
            int cant = 1;
            int k = 0;

            for (int r = 0; r < aprov.Length; r++)
            {
                aprov[r] = -1;
            }

            while (j < convalidaciones.GetLength(0))
            {
                if (convalidaciones[i, j] == true && i != j)
                {
                    if (aprov[0] == -1)
                    {
                        aprov[k] = i;
                        aprov[k + 1] = j;
                        k += 2;
                        j++;
                        cant++;
                    }

                    else
                    {
                        if (aprov[0] == i)
                        {
                            aprov[k] = j;
                            if ((k + 1) < aprov.Length)
                            {
                                k++;
                            }
                            j++;
                            cant++;
                        }
                    }
                }

                else
                {
                    j++;
                }
            }


            return (aprov, cant);
        }

        static bool[] Regress(List<int> cantidad, List<int[]> asignaturas, List<int> actual1, List<int> actual2, bool[] respuesta, int[] toremove)
        {

            if (asignaturas.Count == 0)
            {
                return respuesta;
            }

            if (asignaturas.Count == 1)
            {
                respuesta[asignaturas[0][0]] = true;
                return respuesta;
            }

            if (actual1[1] == -1 && actual2[1] == -1)
            {
                for (int w = 0; w < respuesta.Length; w++)
                {
                    respuesta[w] = true;
                }
                return respuesta;
            }

            if (actual1[1] != -1 && actual2[1] == -1)
            {
                respuesta[actual1[0]] = true;
                return respuesta;
            }


            if (cantidad[actual1[0]] > cantidad[actual2[0]])
            {
                respuesta[actual1[0]] = true;

                for (int n = actual1.Count - 1; n >= 0; n--)
                {
                    asignaturas.Remove(asignaturas[actual1[n]]);
                    cantidad.Remove(cantidad[actual1[n]]);
                    int m = 0;
                    toremove[m] = actual1[n];
                    m++;
                }

                if (asignaturas.Count > 1)
                {
                    var res1 = Actuales(cantidad, asignaturas);
                    List<int> a1 = res1.actual1;
                    List<int> a2 = res1.actual2;
                    var res2 = Removable(toremove, a1, a2);
                    actual1 = res2.actual1;
                    actual2 = res2.actual2;

                    return Regress(cantidad, asignaturas, actual1, actual2, respuesta, toremove);
                }

                if (asignaturas.Count == 1)
                {
                    respuesta[asignaturas[1][1]] = true;
                    return respuesta;
                }
            }

            else if (cantidad[actual1[0]] == cantidad[actual2[0]])
            {
                int count = 0;

                for (int l = 1; l < actual1.Count; l++)
                {
                    if (actual1[l] == actual2[l])
                    {
                        count++;
                    }
                }

                if (count == actual1.Count)
                {
                    respuesta[actual1[0]] = true;
                    asignaturas.Remove(asignaturas[actual2[0]]);
                }

                if (count == actual1.Count - 1)
                {
                    for (int z = 0; z < respuesta.Length; z++)
                    {
                        if (respuesta[z] == true)
                        {
                            if (actual1[actual1.Count - 1] == z)
                            {
                                respuesta[actual2[0]] = true;
                                return respuesta;
                            }

                            if (actual2[actual1.Count - 1] == z)
                            {
                                respuesta[actual1[0]] = true;
                                return respuesta;
                            }
                        }

                        return respuesta;
                    }
                }

                else if (count == 0)
                {
                    for (int q = 1; q < actual1.Count; q++)
                    {
                        if (actual1[q] == actual2[0])
                        {
                            actual1 = actual2;
                        }

                        else if (actual2[q] == actual1[0])
                        {
                            actual2 = actual1;
                        }
                    }

                    int hav = actual1.Count;
                    List<List<int>> have = new();

                    for (int g = 0; g < asignaturas.Count; g++)
                    {
                        if (asignaturas[g] != actual1.ToArray() && asignaturas[g] != actual2.ToArray() && asignaturas[g].Length == hav)
                        {
                            have.Add(asignaturas[g].ToList());
                        }
                    }

                    if (have.Count >= 1)
                    {
                        if (actual1 == actual2)
                        {
                            for (int t = 0; t < have.Count; t++)
                            {
                                actual2 = have[t];
                                asignaturas = Eliminate(asignaturas, actual1, actual2);

                                if (actual1[0] != int.MaxValue && actual1[0] != -1)
                                {
                                    respuesta[actual1[0]] = true;
                                }

                                respuesta[actual2[0]] = true;

                                if ((t + 1) < have.Count && (t + 2) < have.Count)
                                {
                                    actual1 = have[t + 2];
                                }

                                else if ((t + 1) < have.Count)
                                {
                                    for (int u = 0; u < actual1.Count; u++)
                                    {
                                        actual1[u] = int.MaxValue;
                                    }
                                }

                            }

                            return Regress(cantidad, asignaturas, actual1, actual2, respuesta, toremove);

                        }

                        else
                        {
                            asignaturas = Eliminate(asignaturas, actual1, actual2);
                            respuesta[actual1[0]] = true;
                            respuesta[actual2[0]] = true;
                            return Regress(cantidad, asignaturas, actual1, actual2, respuesta, toremove);
                        }
                    }

                    else
                    {
                        asignaturas = Eliminate(asignaturas, actual1, actual2);
                        respuesta[actual1[0]] = true;
                        respuesta[actual2[0]] = true;
                        return Regress(cantidad, asignaturas, actual1, actual2, respuesta, toremove);
                    }

                }

                else
                {
                    int hav = actual1.Count;
                    List<List<int>> have = new();

                    for (int g = 0; g < asignaturas.Count; g++)
                    {
                        if (asignaturas[g] != actual1.ToArray() && asignaturas[g] != actual2.ToArray() && asignaturas[g].Length == hav)
                        {
                            have.Add(asignaturas[g].ToList());
                        }
                    }

                    if (have.Count >= 1)
                    {
                        for (int t = 0; t < have.Count; t++)
                        {
                            actual2 = have[t];
                            asignaturas = Eliminate(asignaturas, actual1, actual2);

                            if (actual1[0] != int.MaxValue)
                            {
                                respuesta[actual1[0]] = true;
                            }

                            respuesta[actual2[0]] = true;

                            if ((t + 1) < have.Count && (t + 2) < have.Count)
                            {
                                actual1 = have[t + 2];
                            }

                            else if ((t + 1) < have.Count)
                            {
                                for (int u = 0; u < actual1.Count; u++)
                                {
                                    actual1[u] = int.MaxValue;
                                }
                            }
                        }
                        return Regress(cantidad, asignaturas, actual1, actual2, respuesta, toremove);
                    }

                    else
                    {
                        asignaturas = Eliminate(asignaturas, actual1, actual2);
                        respuesta[actual1[0]] = true;
                        respuesta[actual2[0]] = true;
                        return Regress(cantidad, asignaturas, actual1, actual2, respuesta, toremove);
                    }
                }

            }

            else
            {
                var temp = actual1;
                actual1 = actual2;
                actual2 = temp;
                return Regress(cantidad, asignaturas, actual1, actual2, respuesta, toremove);
            }

            return respuesta;
        }


        static (List<int> actual1, List<int> actual2) Actuales(List<int> cantidad, List<int[]> asignaturas)
        {
            int indmax = cantidad.IndexOf(cantidad.Max());
            var actual1 = asignaturas[indmax].ToList();
            cantidad[indmax] = int.MinValue;

            indmax = cantidad.IndexOf(cantidad.Max());
            var actual2 = asignaturas[indmax].ToList();
            cantidad[indmax] = int.MinValue;

            return (actual1, actual2);
        }

        static (List<int> actual1, List<int> actual2) Removable(int[] toremove, List<int> actual1, List<int> actual2)
        {
            for (int f = toremove.Length - 1; f >= 0; f--)
            {
                for (int d = actual1.Count - 1; d >= 0; d--)
                {
                    if (toremove[f] == actual1[d])
                    {
                        actual1.Remove(actual1[d]);
                    }
                }

                for (int d = actual2.Count - 1; d >= 0; d--)
                {
                    if (toremove[f] == actual2[d])
                    {
                        actual2.Remove(actual2[d]);
                    }
                }
            }
            return (actual1, actual2);
        }

        static List<int[]> Eliminate(List<int[]> asignaturas, List<int> actual1, List<int> actual2)
        {
            List<int> all = new();
            int end = 0;

            while (end == 0)
            {
                if (actual1.Max() != int.MinValue)
                {
                    if (actual2.Max() != int.MinValue)
                    {
                        if (actual1.Max() > actual2.Max())
                        {
                            all.Add(actual1.Max());
                            actual1[actual1.IndexOf(actual1.Max())] = int.MinValue;
                        }

                        else
                        {
                            all.Add(actual2.Max());
                            actual2[actual2.IndexOf(actual2.Max())] = int.MinValue;
                        }
                    }

                    else
                    {
                        all.Add(actual1.Max());
                        end = 1;
                    }

                }

                if (actual2.Max() != int.MinValue)
                {
                    all.Add(actual2.Max());
                    end = 1;
                }
            }

            for (int i = all.Count - 1; i >= 0; i--)
            {
                if (all[i] < asignaturas.Count)
                {
                    asignaturas.Remove(asignaturas[all[i]]);
                }
            }

            return asignaturas;
        }
    }
}




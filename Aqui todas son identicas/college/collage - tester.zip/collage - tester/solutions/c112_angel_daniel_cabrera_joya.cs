﻿namespace Weboo.Examen
{
    public class Examenes
    {
        public static bool[] MinimoEstudio(bool[,] convalidaciones)
        {
            bool[] Necesita_Pa_Aprobar = new bool[convalidaciones.GetLength(0)];
            bool[] Chekiadas = new bool[convalidaciones.GetLength(0)];
            return MinimoAsignaturas(convalidaciones, Chekiadas, Necesita_Pa_Aprobar, 0, new bool[convalidaciones.GetLength(0)]);
        }
        static public bool[] MinimoAsignaturas(bool[,] convalidaciones, bool[] Chekiadas, bool[] Necesita_Pa_Aprobar, int index, bool[] mejorAprobadas)
        {
            if (Check(Chekiadas))
            {
                if ( Necesitas_Aprobar(mejorAprobadas) > Necesitas_Aprobar(Necesita_Pa_Aprobar))
                {
                    return Necesita_Pa_Aprobar;
                }
                return mejorAprobadas;
            }
            
            for (int i = 0; i < convalidaciones.GetLength(0); i++)
            {
                if (convalidaciones[i,index])
                {
                    Necesita_Pa_Aprobar[i] = true;
                    Chekiadas[i] = true;
                    Chekiadas[index] = true;

                    mejorAprobadas = MinimoAsignaturas(convalidaciones, Chekiadas, Necesita_Pa_Aprobar, index + 1, mejorAprobadas);

                 // Necesita_Pa_Aprobar[i] = false;
                    Chekiadas[i] = false;
                    Chekiadas[index] = false;

                    index = 0;
                }
            }
            return mejorAprobadas;
        }

        public static int Necesitas_Aprobar(bool[] Necesita_pa_Aprobar)
        {
            int a = 0;
            for (int i = 0; i < Necesita_pa_Aprobar.Length; i++)
            {
                if (Necesita_pa_Aprobar[i])
                {
                    a++;
                }
            }
            if (a == 0) { return int.MaxValue; }
            else return a;
        }

        public static bool Check(bool[] Chekiadas)
        {
            for (int i = 0; i < Chekiadas.Length; i++)
            {
                if (!Chekiadas[i])
                {
                    return false;
                }
            }
            return true;
        }

      
    }

}

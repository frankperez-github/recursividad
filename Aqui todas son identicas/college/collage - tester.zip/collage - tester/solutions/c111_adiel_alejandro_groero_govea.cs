﻿namespace Weboo.Examen
{
    public class Examenes
    {
        public static bool[] MinimoEstudio(bool[,] convalidaciones)
        {   

           List<int>[] conex = new List<int>[convalidaciones.GetLength(0)];
           
           for(int i= 0; i<convalidaciones.GetLength(0); i ++){
               List<int> aux = new List<int>();
               for(int j = 0; j<convalidaciones.GetLength(1); j++){
           
                   if(convalidaciones[i,j]){
                       aux.Add(j);
                    }

               }
               conex[i] = aux;
           }
           

           return Calcular(conex);
           
        }

        public static bool[] Calcular(List<int>[] conex){
            bool[] mat = new bool[conex.Length];
            bool[] mark = new bool[conex.Length];
            int[] elem = new int[conex.Length +1];
            int[] nos = new int[conex.Length+1];
            for(int i = 0; i< nos.Length -1; i++){
                nos[i] = 1;
            }
            nos[nos.Length-1] = conex.Length;

           /* elem = variaciones(conex, elem, 0, mark, nos, conex.Length);


            for(int i = 0 ; i < elem.Length-1 ; i++){
                if(elem[i] == 1 )
                mat[i] = true;
//Console.Write(mat[i]+ " ");
            }
            */
            
            int t = variaciones(conex, elem, 0, mark,mat, conex.Length);
            for(int i = 0 ; i < t ; i++){
                mat[i] = true;
            }
            
            return mat;
        }

       /*public static int[] variaciones(List<int>[] conex, int[] elemt,int pos, bool[] mark, int[] nos, int min){
            
            if(pos == conex.Length){
                int[] me = nos;
                int c = min;
                bool[] aux = new bool[nos.Length-1] ;
                
                
                
                min = Hijos(conex,elemt,aux, min);
                 for(int i = 0; i < me.Length -1; i++){
                    me[i] = 0;
                    if(aux[i]){
                        me[i] =1;
                    }
//Console.Write(me[i] + " ");

                    
                
                }
                
                
                if( c < min){
                                        
                me = nos;    
                   
                
                }
                min = c;
                me[me.Length-1] = min;

                return me;
            }

            int[] nue = new int[nos.Length];
             
            for(int i = 0 ; i < conex.Length; i ++){
                if(!mark[i]){
                    mark[i] = true;
                    elemt[pos] = i;
                    min = nue[nue.Length-1];
                    nue = variaciones(conex, elemt, ++pos, mark, nue, min);
                    min = nue[nue.Length-1];
                    pos --;
                    mark[i]  = false;
                }
                
            }
            

            return nue;

        }*/


        public static int Hijos(List<int>[] conex, int[] elemt,bool[] aux,int min){
            bool[] visit =  new bool[elemt.Length];
            int c = 0;
            for(int i = 0; i < elemt.Length; i++){
                int t = elemt[i];
                
                if(!visit[t]){
                   
                    c++;
                    
                    if( c > min) return min;
                    visit[t] = true;
                    aux[t] = true;
                    for(int j =0; j < conex[t].Count; j++){
                        visit[conex[t][j]] = true;
                    }
                }
                
            }
            
            return c;

        }

        public static int variaciones(List<int>[] conex, int[] elemt,int pos, bool[] mark, bool[] mat, int min){
            
            if(pos == conex.Length){
               
                int c = min;
                bool[] aux = new bool[mat.Length] ;
                
                
                
                min = Hijos(conex,elemt,aux, min);
                
                if( c > min){
                                        
                    c = min;
                }
                min = c;
                
                return min;
            }

            
            for(int i = 0 ; i < conex.Length; i ++){
                if(!mark[i]){
                    mark[i] = true;
                    elemt[pos] = i;
                    min = variaciones(conex, elemt, ++pos, mark, mat, min);
                   
                    pos --;
                    mark[i]  = false;
                }
                
            }
            return min;

        }

    }
}

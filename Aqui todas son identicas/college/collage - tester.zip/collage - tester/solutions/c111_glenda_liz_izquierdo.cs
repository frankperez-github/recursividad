﻿namespace Weboo.Examen
{
    public class Examenes
    {
        public static bool[] MinimoEstudio(bool[,] convalidaciones)
        {
            return MinimoEstudio1(convalidaciones, 0, 1, convalidaciones.GetLength(0) - 1);
        }

        public static bool[] MinimoEstudio1(bool[,] convalidaciones, int filaActual, int iteracionfila, int contadorReversodefilas)
        {
            if (!HayQueAprobarCadaAsignatura(convalidaciones))
            {
                if (contadorReversodefilas == 2)
                {

                    List<int> fila1 = AsignaturasAsociadas(filaActual, convalidaciones);
                    List<int> fila2 = AsignaturasAsociadas(iteracionfila, convalidaciones);

                    return (fila1.Count >= fila2.Count) ? AsignaturasQueHayQueAprobar3(ExtraeFilaDe(convalidaciones, filaActual),filaActual) : AsignaturasQueHayQueAprobar3(ExtraeFilaDe(convalidaciones, iteracionfila),iteracionfila);
                }
                if(convalidaciones.GetLength(0) == 2) return MinimoEstudio1(convalidaciones,0,1,2);
                List<int> filaComparativa1 = AsignaturasAsociadas(filaActual, convalidaciones);

                List<int> filaComparativa2 = AsignaturasAsociadas(iteracionfila, convalidaciones);


                int iteracionFilaComparativa2 = iteracionfila;
                iteracionfila++;


                if (filaComparativa2.Count >= filaComparativa1.Count)
                {
                    if (iteracionfila == convalidaciones.GetLength(0) - 1)
                    {
                        return MinimoEstudio1(convalidaciones, iteracionFilaComparativa2, iteracionfila, 2);
                    }

                    return MinimoEstudio1(convalidaciones, iteracionFilaComparativa2, iteracionfila, contadorReversodefilas--);
                }
                if (iteracionfila == convalidaciones.GetLength(0) - 1)
                {
                    return MinimoEstudio1(convalidaciones, filaActual, iteracionfila, 2);
                }
                return MinimoEstudio1(convalidaciones, filaActual, iteracionfila, contadorReversodefilas--);


            }
            return CadaAsignaturaDebeAprobarse(convalidaciones.GetLength(1));

        }





        #region MetodosAuxiliares
        private static bool[] CadaAsignaturaDebeAprobarse(int columnas)
        {   //devuelve una mascara de valores true indicando que cada asignatura debe aprobarse
            bool[] resultado = new bool[columnas];
            for (int i = 0; i < resultado.Length; i++)
            {
                resultado[i] = true;
            }
            return resultado;
        }
        private static bool[] ExtraeFilaDe(bool[,] convalidaciones, int fila)
        {
            bool[] resultado = new bool[convalidaciones.GetLength(1)];
            for (int i = 0; i < convalidaciones.GetLength(1); i++)
            {
                resultado[i] = convalidaciones[fila, i];
            }
            return resultado;
        }
        private static bool[] AsignaturasQueHayQueAprobar(bool[] asignaturas)
        {
            for (int i = 1; i < asignaturas.Length; i++)
            {
                if (asignaturas[i]) { asignaturas[i] = false; }
            }
            return asignaturas;
        }
        private static bool[] AsignaturasQueHayQueAprobar3(bool[] asignaturas, int k)
        {
            for (int i = 0; i < asignaturas.Length; i++)
            {
                if (i != k)
                {
                    if (asignaturas[i]) { asignaturas[i] = false; }
                    else asignaturas[i] = true;
                }
            }
            return asignaturas;
        }

        private static bool[] AsignaturasQueHayQueAprobar2(bool[] asignaturas, List<int> aso, List<int> noaso)
        {
            if (aso.Count != 0)
            {
                for (int i = 1; i < aso.Count; i++)
                {
                    asignaturas[i] = false;
                }
            }
            if (noaso.Count != 0)
            {
                for (int j = 0; j < noaso.Count; j++)
                {
                    asignaturas[j] = true;
                }
            }
            return asignaturas;
        }
        private static List<int> AsignaturasAsociadas(int asignatura, bool[,] convalidaciones)
        {
            List<int> asignaturas = new List<int>();

            for (int j = 0; j < convalidaciones.GetLength(1); j++)
            {   //este metodo no se agrega a si mismo como asignatura asociada.
                if (convalidaciones[asignatura, j] && j != asignatura) { asignaturas.Add(j); }
            }

            return asignaturas;
        }
        private static List<int> AsignaturasNoAsociadas(int asignatura, bool[,] convalidaciones)
        {
            List<int> asignaturas = new List<int>();

            for (int j = 0; j < convalidaciones.GetLength(1); j++)
            {   //este metodo no se agrega a si mismo como asignatura asociada.
                if (!convalidaciones[asignatura, j]) { asignaturas.Add(j); }
            }

            return asignaturas;
        }
        private static bool HayQueAprobarCadaAsignatura(bool[,] convalidaciones)
        {
            for (int i = 0; i < convalidaciones.GetLength(0); i++)
            {
                for (int j = 0; j < convalidaciones.GetLength(1); j++)
                {
                    if (i != j && convalidaciones[i, j])
                    {
                        return false;
                    }
                }
            }
            return true;
        }
        #endregion

    }
}


﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weboo.Examen
{
    public class Examenes
    {
        public static bool[] MinimoEstudio(bool[,] convalidaciones)
        { 
            int contador_convalidan = 0;
            int contador_no_convalidan = 0;
            bool[] resultados = new bool[convalidaciones.GetLength(0)];
            int[] paraComparar = new int[convalidaciones.GetLength(0)];
            for (int i = 0; i < convalidaciones.GetLength(0); i++)
            {   for(int m=0; m< resultados.Length; m++)
                    //por defecto todo el array esta en false
                {
                    for (int j = 0; j < convalidaciones.GetLength(1); j++)
                        //recorro la matriz para conocer las asignaturas aprobadas,q convalidan a las demas
                        for (int k = 0; k < paraComparar.Length; k++)
                        {
                         {

                                if (convalidaciones[i, j] == true)
                                //convalida la asignatura Aj
                                {
                                    resultados[m] = true;
                                    if (convalidaciones[i, j + 1] == true)
                                    //para verificar si aprobando esta asignatura me convalida las demas
                                    {
                                        resultados[m] = convalidaciones[i, j];
                                        //marco ese valor de true en el array
                                        contador_convalidan++;
                                        //por cada valor true sumo 1
                                        paraComparar[k] = contador_convalidan;
                                        //pongo los valores q me dio el contador por fila
                                        contador_convalidan = 0;
                                        //cuando pasa a la siguiente fila el contador se hace 0


                                    }
                                   if (convalidaciones[i, j + 1] == false)
                                    //no me convalida las otras asignaturas
                                    //igual funcionaba con else
                                    {
                                        resultados[m] = true;
                                        contador_no_convalidan++;
                                        //en este caso cuento solo los true
                                        //aunque cambie de fila sigue sumando
                                        paraComparar[k] = contador_no_convalidan;
                                        //todo me va a devolver true
                                        
                                        
                                    }
                                    //ahi vendria el backtrack, sino se cumple una condicion la desecha y revisa
                                    //la otra
                                   

                                }
                                else
                                    resultados[m] = false;
                                paraComparar[k] = 0;

                                return resultados;
                               
                                /*  else
                                paraComparar[k] = 0;
                                for (int l = 0; l < paraComparar.Length; l++)
                                {
                                    int aux;
                                    while (paraComparar[l] > paraComparar[l + 1])
                                    {//ordena el array
                                        aux = paraComparar[l];
                                        paraComparar[l] = paraComparar[l + 1];
                                        paraComparar[l + 1] = aux;
                                    }
//Console.WriteLine(paraComparar);
                                }
                                resultados[m] = convalidaciones[i, 0];
//Console.WriteLine("estos son los resultados" + resultados);*/

                            }

                        }
                } 
            }
            for (int u = 0; u < paraComparar.Length; u++)
            {
                int aprobados = paraComparar[u] + paraComparar[u + 1];
//Console.WriteLine("el resultado fue" + aprobados);
            }
            
//Console.WriteLine(resultados);

           // return MinimoEstudio( resultados[]);
            //asi seria recursividad llamando al mismo metodo
            return resultados;
            //temporalmente para q no me de error:)
           
        }
    }

}

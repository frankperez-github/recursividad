﻿namespace Weboo.Examen
{
    public class Examenes
    {

        public static bool[] MinimoEstudio(bool[,] convalidaciones)
        {
            bool [] asignaturas= new bool[convalidaciones.GetLength(1)];
          

            return Recursivo(convalidaciones,0, int.MinValue,0,asignaturas,0,0);
        }
        public static bool [] Recursivo (bool [,] convalidaciones, int cuantas, int min, int columna, bool [] asignaturas, int index, int columnaMin)
        {
            
            if(index==(convalidaciones.GetLength(0)*convalidaciones.GetLength(1)))
            {

                return dame (columnaMin, convalidaciones);
               
            }
            for (int i = 0; i < asignaturas.Length ; i++)
            {
                if(convalidaciones[i,columna])
                {
  
                    if(cuantas>min)
                    {
                        min=cuantas;
                        columnaMin=columna;

                    }
                    
                    Recursivo(convalidaciones,cuantas+1,min,columna,asignaturas,index+1,columnaMin);

                }
              index++;
            }
            if(columna + 1 < convalidaciones.GetLength(0))
            {
                Recursivo(convalidaciones,0,min,columna+1,asignaturas,index+1,columnaMin);
                
            }
     
            return asignaturas;
        }
        public static bool [] dame(int columna, bool [,] convalidaciones)
        {
            bool [] asignaturas=new bool[convalidaciones.GetLength(0)];
            for (int i = 0; i < convalidaciones.GetLength(1) ; i++)
            {
                asignaturas[i]=convalidaciones[columna,i];
            }
            return asignaturas;
        }
    }

}

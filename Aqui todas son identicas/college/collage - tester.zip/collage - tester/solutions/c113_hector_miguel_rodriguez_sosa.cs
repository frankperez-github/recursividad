﻿namespace Weboo.Examen
{
    public class Examenes
    {
        public static bool[] MinimoEstudio(bool[,] convalidaciones)
        {
            int n = convalidaciones.GetLength(0);
            int min = int.MaxValue;
            bool[] res = new bool[n];
            Generar(convalidaciones,new bool[n],0,ref min, res);
            return res;

        }
        static void Generar(bool[,] g, bool[] path, int p, ref int min, bool[] res){
            if(p==path.Length){
                if(Correcta(g,path)){ //Determino si aprobando la cantidad de asignaturas que aprobe puedo pasar el curso
                    int x = Contar(path,p); //Cuento cuantas asignaturas aprobe
                    if(x<min){ //Si es menor esa cantidad al minimo global entonces modifica el minimo global y copia el array de asignaturas
                        min = x;
                        path.CopyTo(res,0);
                    }
                }
                return;
            }
            if(Contar(path,p)>min) return; //La poda de si ya he aprobado mas asignaturas que el minimo entonces no sigas
            for (int i = 0; i < 2; i++) //Genero todas las posibles variaciones que hay de aprobar una asignatura o no aprobarla
            {
                if(i==0) path[p]=true;
                if(i==1) path[p]=false;
                Generar(g,path,p+1, ref min, res);
            }

        }
        static bool Correcta(bool[,] g, bool[] path){ //Me determina si aprobe todas las asignaturas habiendo aprobado las q aprobe
            bool[] aux = new bool[path.Length]; //Creo un array auxiliar que seran las q aprobe en total
            for (int i = 0; i < path.Length; i++)
            {
                if(path[i]){ //Si aprobe esta asignaturas entonces aprobe esa y todas las q esa convalida
                    for (int j = 0; j < g.GetLength(1); j++)
                    {
                        if(g[i,j]) aux[j] = true;
                    }
                }
            }
            for (int i = 0; i < aux.Length; i++) //Si quedo alguna por aprobar entonces esa solucion no es correcta
            {
                if(!aux[i]) return false;
            }
            return true;
        }
        static int Contar(bool[] path, int p){ //Cuento cuantas asignaturas aprobe
            int count = 0;
            for (int i = 0; i < p; i++)
            {
                if(path[i]) count+=1;
            }
            return count;
        }
    }

}

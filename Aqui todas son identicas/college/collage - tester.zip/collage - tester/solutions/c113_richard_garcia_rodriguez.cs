﻿namespace Weboo.Examen
{
    public class Examenes
    {
        public static bool[] MinimoEstudio(bool[,] convalidaciones)
        {
            bool[] aprobadas = new bool[convalidaciones.GetLength(0)];
            bool[] convalidadas = new bool[convalidaciones.GetLength(1)];
        
            return(MinimoEstudio(convalidaciones,aprobadas,convalidadas));
        }


        private static bool[] MinimoEstudio(bool[,] convalidaciones, bool[] aprobadas, bool[] convalidadas)
        {
            bool[] mejor = new bool[aprobadas.Length];

            if(Chequear(convalidadas)) return aprobadas;         
            
                for(int i=0;i<convalidaciones.GetLength(0);i++)
                {
                    bool[] actual=new bool[convalidadas.Length];
                    if(!aprobadas[i])
                    {
                        aprobadas[i]=true;
                        for(int j=0;j<convalidaciones.GetLength(1);j++)
                        {
                            if(convalidaciones[i,j]){convalidadas[j]=true;actual[j]=true;}
                        }
                        if(NoVacio(mejor))mejor = MejorSolucion(mejor,MinimoEstudio(convalidaciones,aprobadas,convalidadas));
                        else mejor = MinimoEstudio(convalidaciones,aprobadas,convalidadas); 
                        //aprobadas[i]=false;
                        //for(int j=0;j<convalidadas.Length;j++)
                        //{
                        //    if(convalidadas[j] && actual[j])convalidadas[j]=false;
                        //}
                    }
                }   
            return mejor; 
        }

        private static bool NoVacio(bool[] a)
        {
            for(int i=0;i<a.Length;i++)
            {
                if(a[i])return true;
            }
            return false;
        }
 
        private static bool[] MejorSolucion(bool[] a, bool[] b)
        {
            int countA=0;
            int countB=0;
            for(int i=0;i<a.Length;i++){if(a[i])countA++;}
            for(int i=0;i<b.Length;i++){if(b[i])countB++;}
            return (countA<countB)? a : b ;
        }

        private static bool Chequear(bool[] convalidadas)
        {
            for(int i=0;i<convalidadas.Length;i++)
            {
                if(!convalidadas[i])return false;
            }
            return true;
        }
    }

}

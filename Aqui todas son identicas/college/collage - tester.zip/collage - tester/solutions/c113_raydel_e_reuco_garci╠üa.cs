﻿using System.Globalization;
namespace Weboo.Examen
{
    public class Examenes
    {
        public static bool[] MinimoEstudio(bool[,] convalidaciones)
        {
            // Primeramente la solucion esta reflejada tomando en cuanta que como minimo
            // cada asignatura se convalida a si misma por tanto el maximo numero sera
            // la cantidad de asignaturas y el minimo 1 siendo esa asignatura la que 
            // convalide al resto.


            // Probamos en caso de que sea vacia la matriz y se asume que es cuadrada debido a que es [Cantidad de Asignaturas x Cantidad de Asignaturas]
            if(convalidaciones!=null)
            {
                // Declaramos el array de bool para nuestra asignatura inicial con todos sus valores en true como el maximo
                bool[] asignatura = new bool[convalidaciones.GetLength(0)];

                for (int i = 0; i < asignatura.Length; i++)
                {
                    asignatura[i]=true;
                }

                // Ejecutamos el metodo recursivo
                return FindMin(convalidaciones,asignatura,0);
            }
            else
            {
                throw new Exception("ERROR-No deberia ser null la matriz \"convalidaciones\" , Compruebe");
            }
        
        }
        public static bool[] FindMin(bool[,] convalidaciones , bool[] asignatura , int count)// Metodo recursivo para ir recorriendo por cada fila que representa una asignatura a cuantas cinvalida la misma
        {

            // Caso de parada si se recorrieron todas las asignaturas y se devuelve la que mas asignaturas convalida
            if(count>asignatura.Length-1)
                return asignatura;
            
            // Array donde guardaremos los valores para la nueva asignatura
            bool[] new_asignatura = new bool[convalidaciones.GetLength(0)];

            // Le asignamos todos sus valores a true para dejar las asignaturas que convalida como false    
            for (int i = 0; i < new_asignatura.Length; i++)
            {
                new_asignatura[i]=true;
            }

            // Recorremos por cada una de las demas asignaturas  
            for (int i = 0; i < convalidaciones.GetLength(1); i++)
            {
                // Si nuestra asignatura actual convalida la que estamos evaluando y por supuesto no es ella misma le asignamos false
                if(convalidaciones[count,i] && i!=count)
                {
                    new_asignatura[i]=false;
                }
            
            }

            // Si la nueva asignatura convalida mas que la anterior ejecutamos el metodo recursivo para que evalue las demas con esa
            if(BoolCount(new_asignatura)<BoolCount(asignatura) && BoolCount(new_asignatura) >0)
                return FindMin(convalidaciones,new_asignatura,count+1); 

            // En el caso contrario simplemente se sigue con la otra   
            else       
                return FindMin(convalidaciones,asignatura,count+1);
        }
        public static int BoolCount(bool[] bc) // Metodo simple para contar la cantidad de valores true del array
        {
            int count=0;

            for (int i = 0; i < bc.Length; i++)
            {
                if(bc[i])
                    count++;
            }
            return count;
        }

    }

}

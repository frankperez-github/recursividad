﻿namespace Weboo.Examen
{
    public class Examenes
    {
        public static bool[] MinimoEstudio(bool[,] convalidaciones)
        {
            bool[] asignaturas = new bool[convalidaciones.GetLength(0)];
            SetTrue(asignaturas);

            MinimoEstudio(convalidaciones, new bool[convalidaciones.GetLength(0)], asignaturas, new bool[convalidaciones.GetLength(0)], 0);
            return asignaturas;
        }

        public static void MinimoEstudio(bool[,] convalidaciones, bool[] combinacion, bool[] asignaturas, bool[] aux, int i)
        {
            if (Satisface(convalidaciones, combinacion))
                Array.Copy(combinacion, aux, aux.Length);
            else
            {
                if (i < combinacion.Length)
                {
                    if (!combinacion[i])
                    {
                        combinacion[i] = true;
                        MinimoEstudio(convalidaciones, combinacion, asignaturas, aux, i + 1);
                        combinacion[i] = false;
                    }
                    MinimoEstudio(convalidaciones, combinacion, asignaturas, aux, i + 1);
                }
            }
            if (CheckAsignaturas(aux) < CheckAsignaturas(asignaturas))
                    Array.Copy(aux, asignaturas, aux.Length);
        }

        private static void SetTrue(bool[] array)
        {
            for (int i = 0; i < array.Length; i++)
                array[i] = true;
        }

        private static int CheckAsignaturas(bool[] array)
        {
            int aux = 0;

            for (int i = 0; i < array.Length; i++)
                if (array[i])
                    aux++;

            return aux;
        }

        private static bool Satisface(bool[,] convalidaciones, bool[] asignaturas)
        {
            int aux = 0;
            bool[,] convalidada = new bool[convalidaciones.GetLength(0), convalidaciones.GetLength(0)];

            for (int i = 0; i < asignaturas.Length; i++)
            {
                if (asignaturas[i])
                {
                    for (int j = 0; j < asignaturas.Length; j++)
                    {
                        if (convalidaciones[i,j] && !convalidada[i,j])
                        {
                            convalidada[i,j] = true;
                            convalidada[j,j] = true;
                            aux++;
                        }    
                    }
                }
            }

            if (aux == asignaturas.Length)
                return true;
            return false;
        }
    }
}

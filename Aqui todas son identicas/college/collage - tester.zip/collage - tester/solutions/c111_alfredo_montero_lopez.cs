﻿namespace Weboo.Examen
{
    public class Examenes
    {
        //Almacenamiento para todas las posibles soluciones
        public static List<bool[]> list = new();
        //Valor para podar
        public static int minAmount = int.MaxValue;
        public static bool[] MinimoEstudio(bool[,] convalidaciones)
        {
            //Vuelvo a inicializar las variables para evitar conflicto
            list = new();
            minAmount = int.MaxValue;
            List<int>[] enlaces = new List<int>[convalidaciones.GetLength(0)];
            for (int i = 0; i < convalidaciones.GetLength(0); i++)
            {
                enlaces[i] = new();
                for (int j = 0; j < convalidaciones.GetLength(1); j++)
                {
                    if (i == j)
                        continue;
                    if (convalidaciones[i, j])
                        enlaces[i].Add(j);
                }
            }
            int total = enlaces.Length;
            GetMin(enlaces, new bool[total], 0);
            //--------------------------------------------
            //Se aplicaría el validador del tester y quitando la poda en caso de fallo en los resultados
            //List<int> index = new();
            //for (int i = 0; i < list.Count; i++)
            //{
            //if (TesterValidator(convalidaciones, list[i]))
            //index.Add(i);
            //}
            //List<bool[]> newList = new();
            //for (int i = 0; i < list.Count; i++)
            //{
            //if (index.Contain(i))
            //continue;
            //newList.Add(list[i]);
            //}
            //int min = int.MaxValue;
            //int indice = -1;
            //for (int i = 0; i < newList.Count; i++)
            //{
            //int count = 0;
            //for (int j = 0; j < newList[i].Length; j++)
            //{
            //if (newList[i][j])
            //count++;
            //}
            //if (min > count)
            //{
            //min = count;
            //indice = i;
            //}
            //}
            //return newList[indice];
            //--------------------------------------------

            return list[list.Count - 1];
        }
        public static void GetMin(List<int>[] enlaces, bool[] able, int count)
        {
            if (count == able.Length)
            {
                Validate(enlaces, able);
                return;
            }
            if (count > minAmount)
                return;

            for (int i = 0; i < able.Length; i++)
            {
                if (able[i])
                    continue;
                able[i] = true;
                Validate(enlaces, able);
                GetMin(enlaces, able, count + 1);
                able[i] = false;
            }
        }
        public static void Validate(List<int>[] enlaces, bool[] able)
        {
            int count = 0;
            bool[] check = new bool[able.Length];
            int ableCount = 0;
            for (int i = 0; i < able.Length; i++)
            {
                if (able[i])
                {
                    check[i] = true;
                    ableCount++;
                    for (int k = 0; k < enlaces[i].Count; k++)
                    {
                        check[enlaces[i][k]] = true;
                    }
                }
            }
            for (int i = 0; i < check.Length; i++)
            {
                if (check[i])
                    count++;
            }
            if (count == able.Length)
            {

                if (ableCount < minAmount)
                {
                    bool[] temp = new bool[able.Length];
                    able.CopyTo(temp, 0);
                    minAmount = ableCount;
                    list.Add(temp);
                }
            }
        }
        //Validador extraido del Tester
        public static bool TesterValidator(bool[,] convalidaciones, bool[] solucion)
        {
            // Validamos la solución
            for (int i = 0; i < convalidaciones.GetLength(1); i++)
            {
                // Si no se aprobó la asignatura
                if (!solucion[i])
                {
                    bool convalidada = false;
                    for (int j = 0; j < convalidaciones.GetLength(0); j++)
                    {
                        if (convalidaciones[j, i] && solucion[j])
                        {
                            convalidada = true;
                            break;
                        }
                    }
                    // Si tampoco está convalidada entonces es inválida la solución
                    if (!convalidada)
                    {
                        return false;
                    }
                }
            }
            return true;
        }
    }
}
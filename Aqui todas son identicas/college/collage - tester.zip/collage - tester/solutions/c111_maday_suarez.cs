﻿namespace Weboo.Examen
{
    public class Examenes
    {
        public static bool[] MinimoEstudio(bool[,] convalidaciones)
        {
            bool[] asignaturas = new bool[convalidaciones.GetLength(0)];
            int contador1 = int.MaxValue;

            MinimoEstudio(convalidaciones, new bool[asignaturas.Length], ref asignaturas, 0, ref contador1);
            return asignaturas;
        }
        static void MinimoEstudio(bool[,] convalidaciones, bool[] asignaturas, ref bool[] devolver, int index, ref int contador1)
        {
            if (index == asignaturas.Length)
            {
                if (EsValido(convalidaciones, asignaturas))
                {
                    int contador = 0;
                    for (int i = 0; i < asignaturas.Length; i++)
                    {
                        if (asignaturas[i])
                        {
                            contador++;
                        }
                    }
                    if (contador < contador1)
                    {
                        contador1 = contador;

                        for (int i = 0; i < asignaturas.Length; i++)
                        {
                            if (asignaturas[i])
                            {
                                devolver[i] = true;
                            }
                            else
                            {
                                devolver[i] = false;
                            }
                        }
                    }
                    return;
                }
                return;
            }

            //Aqui genero el conjunto potencia.
            MinimoEstudio(convalidaciones, asignaturas, ref devolver, index + 1, ref contador1);
            asignaturas[index] = true;
            MinimoEstudio(convalidaciones, asignaturas, ref devolver, index + 1, ref contador1);
            asignaturas[index] = false;
        }
        static bool EsValido(bool[,] convalidaciones, bool[] asignaturas)
        {
            List<string> pares = new();
            List<int> estan = new();

            for (int i = 0; i < convalidaciones.GetLength(0); i++)
            {
                if (asignaturas[i])
                {
                    for (int j = 0; j < convalidaciones.GetLength(1); j++)
                    {
                        if (convalidaciones[i, j])
                        {
                            pares.Add(i.ToString() + j.ToString());
                            estan.Add(j);
                        }
                    }
                }
            }
            int contador = 0;

            if (pares.Count >= asignaturas.Length)
            {
                for (int i = 0; i < asignaturas.Length; i++)
                {
                    if (estan.Contains(i))
                    {
                        contador++;
                    }
                }
                if (contador == asignaturas.Length)
                {
                    return true;
                }
            }
            return false;
        }
    }
}

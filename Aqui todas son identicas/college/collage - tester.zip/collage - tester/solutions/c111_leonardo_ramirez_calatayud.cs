﻿namespace Weboo.Examen
{
    public class Examenes
    {
        static int min;
        static List<bool> minBool = new List<bool>();
        public static bool[] MinimoEstudio(bool[,] convalidaciones)
        {
            min = convalidaciones.GetLength(0);
            bool[] materiasTomadas = new bool[convalidaciones.GetLength(0)];
            bool[] minBoolResult = MinimoEstudioR(convalidaciones,materiasTomadas,0,0).ToArray();
            #region Descomentar para Imprimir Solucion
            // foreach (var item in minBoolResult)
            // {
//Console.Write(item+" ");
            // }
//Console.WriteLine();
            #endregion
            return minBoolResult;
        }
        public static List<bool> MinimoEstudioR(bool[,] convalidaciones,bool[] materiasTomadas,int materiaActual,int materiasTrue)
        {
            if(materiaActual == convalidaciones.GetLength(0))
            {
                if(TengoTodas(convalidaciones,materiasTomadas) && materiasTrue<=min) 
                {
                    min = materiasTrue;
                    minBool = materiasTomadas.ToList();
                }
            return minBool;
            }

            if(materiasTrue<min)
            {
                materiasTomadas[materiaActual] = true;
                MinimoEstudioR(convalidaciones,materiasTomadas,materiaActual+1,materiasTrue+1);
            }
            materiasTomadas[materiaActual] = false;
            MinimoEstudioR(convalidaciones,materiasTomadas,materiaActual+1,materiasTrue);
            
        return minBool;
        }
        public static bool TengoTodas(bool[,] convalidaciones,bool[] materiasTomadas)
        {
            int total = 0;
            bool[] tomadas = new bool[convalidaciones.GetLength(0)];
            for (int i = 0; i < convalidaciones.GetLength(0); i++)
            {
                if(!materiasTomadas[i]) continue;
            
                for (int j = 0; j < convalidaciones.GetLength(1); j++)
                {
                    if(convalidaciones[i,j] && !tomadas[j])
                    {
                        tomadas[j]= true;
                        total++;  
                    } 
                }
            }
            if(total == convalidaciones.GetLength(0)) return true;
            return false;
        }
    }

}



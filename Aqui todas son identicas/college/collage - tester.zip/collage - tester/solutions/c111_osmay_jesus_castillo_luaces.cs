﻿namespace Weboo.Examen
{
    public class Examenes
    {
        static int minAprobar = 0;
        public static bool[] MinimoEstudio(bool[,] convalidaciones)
        {
            minAprobar = convalidaciones.GetLength(0);
            bool[] asignaturas = new bool[convalidaciones.GetLength(0)];
            for (int i = 0; i < asignaturas.Length; i++)
            {
                asignaturas[i] = MinimoEstudio(convalidaciones, asignaturas);

            }
            return asignaturas;

        }

        public static bool MinimoEstudio(bool[,] convalidaciones, bool[] asignaturas)
        {

            for (int i = 0; i < convalidaciones.GetLength(0); i++)
            {
                for (int j = 0; j < convalidaciones.GetLength(1); j++)
                {
                    if (EsValido(convalidaciones, asignaturas, i, j))
                    {
                        return asignaturas[i];

                    }

                }
            }
            return false;



        }


        static bool EsValido(bool[,] convalidaciones, bool[] asignaturas, int i, int j)
        {

            if (i != j)
            {
                if (convalidaciones[i, j] == convalidaciones[j, i] == true)
                    asignaturas[i] = true;
            }


            if (i == j)
            {
                if (convalidaciones[i, j] == true)
                    asignaturas[i] = true;
            }
            return asignaturas[i];




            return false;
        }


    }

}

﻿namespace Weboo.Examen
{
    public class Examenes
    {
        public static  bool[] MinimoEstudio(bool[,] convalidaciones)
        {
            bool[] aux = new bool[convalidaciones.GetLength(0)];
            /*if(Todas(convalidaciones)) {
                for(int i=0;i<aux.Length;i++)
                {
                    aux[i]= true;
                }
                return aux;
            }*/
             int min = MinimoEstudio(convalidaciones, ref aux,0,int.MaxValue,new bool[aux.Length]);
             return aux;
        }
        /*private static  bool Todas(bool[,] convalidaciones)
        {
            for(int i=0;i<convalidaciones.GetLength(0);i++)
            {
                for(int j=0;j<convalidaciones.GetLength(1);j++)
                {
                    if(i==j)continue;
                    if(convalidaciones[i,j])
                    {
                        return false;
                    }
                }
            }
            return true;
        }*/
        private static int MinimoEstudio(bool[,] convalidaciones,ref bool[] aux,int asignatura,int min,bool[] mask)
        {
             int tomadas = mask.Where(elem => elem == true).Count();
             
            if(EsValido(convalidaciones,mask))
            {
                 if(tomadas < min)
                 {
                     for(int i=0;i<aux.Length;i++)
                     {
                         aux[i] = mask[i];
                     }
                    
                 }
                  return tomadas;
            }
            if(asignatura >= aux.Length) return int.MaxValue;
            if(tomadas >= min) return int.MaxValue;
            
            min = Math.Min(min,MinimoEstudio(convalidaciones,ref aux,asignatura+1,min,mask));
            mask[asignatura] = true;
            min = Math.Min(min,MinimoEstudio(convalidaciones,ref aux,asignatura+1,min,mask));
            mask[asignatura] = false;

            return min;
        }
        private static  bool EsValido(bool[,] convalidaciones,bool[] visitados)
        {
            int cont =0;
            bool[] aux = new bool[convalidaciones.GetLength(0)];
            for(int i = 0;i<visitados.Length;i++)
            {
               
               if(visitados[i])
               {
                   aux[i] = true;
                for(int j=0;j<convalidaciones.GetLength(0);j++)
                {
                    
                     if(convalidaciones[i,j]){   
                     
                       aux[j] = true;   
                      
                     }
                     }
                }
               }
            for(int i=0;i<aux.Length;i++)
            {
                if(aux[i])cont++;
            }
             
           
            if(cont == visitados.Length)return true;
            return false;
        }
    }

}

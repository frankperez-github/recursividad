import networkx as nx
import matplotlib.pyplot as plt
import json

all_colors = [
'#AAAAAA',
'#AAffAA',
]

# Defining a Class
class GraphVisualization:
   
    def __init__(self):
        self.visual = []
        # print(f'colors: {colors}')
        

    def addEdge(self, a, b):
        temp = [a, b]
        self.visual.append(temp)

    def save(self, filename: str, colors, result: int):
        G = nx.DiGraph()
        G.add_edges_from(self.visual)
        print(f'nodes: {G.nodes}')
        node_colors = [ all_colors[colors[node]] for node in G.nodes]
        edge_colors = [ all_colors[colors[e]] for (e,_) in G.edges]
        nx.draw_networkx(G, node_color = node_colors, edge_color = edge_colors, connectionstyle="arc3,rad=0.1")
        plt.figtext(0.05,0.05,f'Resultado: {result}')
        plt.savefig(filename)
        plt.close()

with open('cached_easy_responses.json') as jsonfile:
    results = json.load(jsonfile)

    for result in results: 
        G = GraphVisualization()
        for e in result['param']:
            G.addEdge(e[0],e[1])
        G.save(f"./plots/{result['seed']}.png",list(result['solution']), result['result'] )



import os, fnmatch
import shutil
import json

raw_dir = './tests'
tester_dir = './tester/tester/tester.csproj'
result_file = './result_easy.json'
result_hard_file = './result_hard.json'
result_dir = './results/'
summary_file = './result.csv'
solution_dir = './tester/code/solution.cs'
solution_source_root = 'collage'
solution_source = 'Examenes.cs'

files = os.listdir(raw_dir)

replaceChars = {'á': 'a',
'é': 'e',
'í': 'i',
'ó': 'o',
'ú': 'u',
'ü': 'u',
' ': '_',
'-': '_',
'\'': ' ',
 }

if(not os.path.exists(summary_file)):
    with open(summary_file, 'wx') as summary:
        summary.write(f"Group, Name, Result, %, Ok, Wrong, Timeout, Exception, Eficiencia, %, Ok, Wrong, Timeout, Exception\n")


for f in files:
    print(f"file: {f}")

    if(os.path.exists(result_file)):
        os.remove(result_file)
    if(os.path.exists(result_hard_file)):
        os.remove(result_hard_file)

    if(f.startswith('.')):
        continue
    
    nf = f.lower().translate(str.maketrans(replaceChars))

    if(os.path.exists(os.path.join(result_dir, nf[:-4] + '.json'))):
        print("Already evaluated")
        continue
    
    # unzip in case no .cs found
    if(not os.path.exists(f'./solutions/{nf[:-4]}.cs')):

        filepath = os.path.join(raw_dir, nf)

        if(f!=nf):
            os.rename(os.path.join(raw_dir, f), filepath)

        if nf.endswith('.zip'):
            os.system(f'unzip \"{filepath}\" -d \"{nf[:-4]}\"')
        elif nf.endswith('.rar'):
            os.system(f'unar -d={raw_dir} {filepath}')
        else:
            continue
    
        print('unzip sucess......................')

        file = ''
        for root, dirs, files in os.walk(nf[:-4]):
            for name in files:
                if((root.endswith(solution_source_root) or root.endswith('college') or root.endswith('examen')) and (name == solution_source or name == 'Class1.cs')):
                    file = os.path.join(root, name)
                    print(file)
                    break

        shutil.copyfile(file, f'./solutions/{nf[:-4]}.cs')
        

        shutil.rmtree(nf[:-4] )

    #     continue
    # continue

    shutil.copyfile(f'./solutions/{nf[:-4]}.cs', solution_dir)
    
    print('source code located.................')

    os.system(f'dotnet run --project {tester_dir}')

    if(os.path.exists(result_file)):
        shutil.copyfile(result_file, os.path.join(result_dir, nf[:-4] + '.json'))
    if(os.path.exists(result_hard_file)):
        shutil.copyfile(result_hard_file, os.path.join(result_dir, nf[:-4] + '_hard.json'))


    

    with open(summary_file, 'a') as summary:
        summary.write(f"{nf[:4]},{nf[4:][:-4].replace('_', ' ')}")

        if( not os.path.exists(result_file)):
             summary.write(f", COMPILATION ERROR, 0%, 0, 0, 0, 0\n")
             continue

        with open(result_file) as f:
            result = json.load(f)
            percent = result['ok'] * 100 / result['total'] 
            summary.write(f", {'SUSPENSO' if percent < 90   else 'APROBADO'}, {percent:.2f}%")
            summary.write(f",  {result['ok']}, {result['wrong']}, {result['timeout']}, {result['exception']}")
        
        if(not os.path.exists(result_hard_file)):
            summary.write(f", NO CALIFICADO, 0%, 0 , 0 , 0 , 0\n")
            continue

        with open(result_hard_file) as f:
            result = json.load(f)
            percent = result['ok'] * 100 / result['total'] 
            summary.write(f", {'EFICIENTE' if result['timeout'] < 10 else 'NO EFICIENTE'}, {percent:.2f}%")
            summary.write(f",  {result['ok']}, {result['wrong']}, {result['timeout']}, {result['exception']}\n")
